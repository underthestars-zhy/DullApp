//
//  DocumentationItem.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import SwiftUI

struct DocumentationItem: View {
    let expanded: Bool
    let finished: Bool
    let text: String

    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                Text(text)
                    .font(.system(size: expanded ? 24 : 21, weight: expanded ? .bold : .semibold, design: .monospaced))
                    .padding(.leading, 30)
                    .foregroundColor(.black)

                Spacer()

                if finished {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 32, weight: .medium))
                        .padding(.trailing, 30)
                        .foregroundColor(.black)
                } else {
                    Image(systemName: "arrow.right")
                        .rotationEffect(expanded ? .degrees(90) : .degrees(0))
                        .font(.system(size: 24, weight: expanded ? .bold : .semibold))
                        .padding(.trailing, 30)
                        .foregroundColor(.black)
                }
            }
            .frame(width: 900, height: 60)
            .background(.white)
            .cornerRadius(20)
            .animation(.easeInOut(duration: 1), value: expanded)
        }
        .disabled(expanded)
    }
}

struct DocumentationItem_Previews: PreviewProvider {
    static var previews: some View {
        DocumentationItem(expanded: true, finished: false, text: "1. hi") {}
            .background(.black)
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
