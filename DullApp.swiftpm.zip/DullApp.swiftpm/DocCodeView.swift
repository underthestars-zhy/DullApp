//
//  DocCodeView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/17.
//

import SwiftUI

struct DocCodeView: View {
    @State var code: String = ""
    let holder: Holder
    let allCode: [Holder]
    @State var focus: Bool = false

    @State var result: String = ""

    @State var errorQuene = [ErrorWrapper]()
    
    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 0) {
                ForEach(errorQuene) { error in
                    ErrorBanner(error: error.error, width: 850)
                        .padding(.top, 30)
                }

                OmenTextField("", text: $code, isFocused: $focus, returnKeyType: .continue)
                    .lineLimit(1...)
                    .foregroundColor(.black)
                    .padding(.top, 20)
                    .padding(.horizontal, 30)
                    .onAppear {
                        code = holder.value
                    }
                    .onChange(of: code) { newValue in
                        holder.value = newValue
                    }
                    .frame(maxHeight: .infinity)

                HStack {
                    DocRunButton {
                        if let scope = preRun() {
                            directRun(scope)
                        }
                    }

                    Spacer()
                }
                .padding(.bottom, 20)
                .padding(.top, 20)
                .padding(.horizontal, 30)

                if !result.isEmpty {
                    HStack {
                        Text(filterResult())
                            .font(.system(size: 21, weight: .semibold, design: .monospaced))
                            .opacity(0.7)
                        Spacer()
                    }
                    .padding(.bottom, 20)
                    .padding(.horizontal, 30)
                }
            }
            .frame(width: 900)
            .background(.white)
            .cornerRadius(20)
        }
        .animation(.easeInOut(duration: 0.5), value: result)
    }

    func preRun() -> DullScope? {
        do {
            return try DullLanguage.shared.preRun(code: gainAllCode(codes: allCode))
        } catch {
            withAnimation(.easeInOut(duration: 0.5)) {
                errorQuene.append(.init(error: error))
            }
            return nil
        }
    }

    func directRun(_ scope: DullScope) {
        result = ""
        let config = [OutputConfig({ str in
            result += str
        })]
        do {
            try DullLanguage.shared.runWithScope(code: code, config: config, scope: scope)
            if result.isEmpty {
                result += "Successfully Run the Code\n"
            }
        } catch {
            withAnimation(.easeInOut(duration: 0.5)) {
                errorQuene.append(.init(error: error))
            }
            return
        }
    }

    func filterResult() -> String {
        String(result[result.startIndex..<(result.index(before: result.endIndex))])
    }

    func gainAllCode(codes: [Holder]) -> String {
        return insertTextBetweenArrayElements(text: "\n", array: codes.map { String($0.value) }).reduce("", +)
    }

    func insertTextBetweenArrayElements(text: String, array: [String]) -> [String] {
        var resultArray = [String]()

        for (index, element) in array.enumerated() {
            resultArray.append(element)

            if index != array.count - 1 {
                resultArray.append(text)
            }
        }

        return resultArray
    }
}

struct DocRunButton: View {
    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                Image(systemName: "paperplane.fill")
                    .foregroundColor(.white)
                    .font(.system(size: 16))
                    .padding(.leading, 15)
                    .padding(.trailing, 8)
                
                Text("RUN")
                    .font(.system(size: 18, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(.trailing, 20)
            }
            .frame(height: 40)
            .background(.black)
            .cornerRadius(20)
        }
    }
}
