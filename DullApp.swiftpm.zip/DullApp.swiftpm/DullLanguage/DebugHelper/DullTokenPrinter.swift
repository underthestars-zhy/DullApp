//
//  DullTokenPrinter.swift
//  
//
//  Created by 朱浩宇 on 2023/4/3.
//

import Foundation

func printTokenTree(_ token: DullToken, indentLevel: Int = 0) {
    let indent = String(repeating: "-", count: indentLevel)

    switch token {
    case .root(let tokens):
        print(indent + "Root:")
        for token in tokens {
            printTokenTree(token, indentLevel: indentLevel + 1)
        }
    case .line(let tokens):
        print(indent + "Line:")
        for token in tokens {
            printTokenTree(token, indentLevel: indentLevel + 1)
        }
    case .scope(let tokens):
        print(indent + "Scope:")
        for token in tokens {
            printTokenTree(token, indentLevel: indentLevel + 1)
        }
    default:
        print(indent + "\(token)")
    }
}
