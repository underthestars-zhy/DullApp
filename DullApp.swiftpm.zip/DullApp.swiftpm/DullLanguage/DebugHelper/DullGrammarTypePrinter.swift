//
//  DullGrammarTypePrinter.swift
//  
//
//  Created by 朱浩宇 on 2023/4/4.
//

import Foundation

func printDullGrammarType(_ grammar: DullGrammarType, indentLevel: Int = 0) {
    let indent = String(repeating: "-", count: indentLevel)

    switch grammar {
    case .root(let grammars):
        print(indent + "Root:")
        for grammar in grammars {
            printDullGrammarType(grammar, indentLevel: indentLevel + 1)
        }
    default:
        print(indent + "\(grammar)")
    }
}
