//
//  File.swift
//  
//
//  Created by 朱浩宇 on 2023/4/3.
//

import Foundation

enum DullToken: Equatable {
    case letKeyword
    case varKeyword
    case swiftKeyword
    case identifier(String)
    case colon
    case type(DullTypeHolder)
    case equal
    case value(DullValueHolder)
    case line([DullToken])
    case root([DullToken])
    case fnKeyword
    case leftParenthesis
    case rightParenthesis
    case comma
    case arrow
    case returnType(String)
    case leftBrace
    case rightBrace
    case scope([DullToken])
    case underscore
    case returnKeyword
    case plus
    case minus
    case multiply
    case divide
    case greaterThan
    case lessThan
    case greaterThanOrEqual
    case lessThanOrEqual
    case equalTo
    case notEqualTo
    case ifKeyword
    case elseKeyword
    case whileKeyword
    case plusEqual
    case minusEqual
    case multiplyEqual
    case and
    case or
    case not
    case guardKeyword
}
