//
//  ScanerError.swift
//  
//
//  Created by 朱浩宇 on 2023/4/14.
//

import Foundation

public enum ScanerError: Error {
    case unexpectedChar(Character)
    case unexpectedValue
    case unclosedStringLiteral
    case multipleDotsFound
}
