//
//  DullScaner.swift
//
//
//  Created by 朱浩宇 on 2023/4/3.
//

import Foundation

class DullScaner {
    let input: String
    var position: String.Index
    var lineNumber: Int

    init(input: String) {
        self.input = input
        self.position = input.startIndex
        self.lineNumber = 1
    }

    func scan() throws -> DullToken {
        var tokens: [DullToken] = []

        var tokenBuffer = [DullToken]()

        while position < input.endIndex {
            let char = input[position]

            switch char {
            case " ":
                advance()
            case "\t":
                advance()
            case "\n":
                if !tokenBuffer.isEmpty {
                    tokens.append(.line(tokenBuffer))
                    tokenBuffer = []
                    lineNumber += 1
                }

                advance()
            case ":":
                tokenBuffer.append(.colon)
                advance()
            case "=":
                if position < input.endIndex && input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.equalTo)
                    advance(2)
                } else {
                    tokenBuffer.append(.equal)
                    advance()
                }
            case "(":
                if case .identifier = tokenBuffer.last {
                    tokenBuffer.append(.leftParenthesis)
                    advance()
                } else {
                    if input[input.index(after: position)] == ")" {
                        if let dullValue = DullVoid.create(from: "()") {
                            tokenBuffer.append(.value(DullValueHolder(value: dullValue)))
                            advance(2)
                        } else {
                            tokenBuffer.append(.leftParenthesis)
                            advance()
                        }
                    } else {
                        tokenBuffer.append(.leftParenthesis)
                        advance()
                    }
                }
            case ")":
                tokenBuffer.append(.rightParenthesis)
                advance()
            case ",":
                tokenBuffer.append(.comma)
                advance()
            case "+":
                if input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.plusEqual)
                    advance(2)
                } else {
                    tokenBuffer.append(.plus)
                    advance()
                }
            case "-":
                let isDigit: (Character) -> Bool = { char in
                    return char >= "0" && char <= "9"
                }

                if position < input.endIndex && input[input.index(after: position)] == ">" {
                    tokenBuffer.append(.arrow)
                    advance(2)
                } else if position < input.endIndex && isDigit(input[input.index(after: position)]) {
                    if let value = try scanValue() {
                        tokenBuffer.append(value)
                    } else {
                        fatalError("Unexpected character: \(char)")
                    }
                } else if input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.minusEqual)
                    advance(2)
                } else {
                    tokenBuffer.append(.minus)
                    advance()
                }
            case "*":
                if input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.multiplyEqual)
                    advance(2)
                } else {
                    tokenBuffer.append(.multiply)
                    advance()
                }
            case "/":
                tokenBuffer.append(.divide)
                advance()
            case "{":
                tokenBuffer.append(.leftBrace)
                advance()
                let scopeTokens = try scan()
                tokenBuffer.append(scopeTokens)
                tokenBuffer.append(.rightBrace)
            case "}":
                if !tokenBuffer.isEmpty {
                    tokens.append(.line(tokenBuffer))
                }

                tokenBuffer.append(.rightBrace)
                advance()

                return .scope(tokens)
            case "_":
                tokenBuffer.append(.underscore)
                advance()
            case ">":
                if position < input.endIndex && input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.greaterThanOrEqual)
                    advance(2)
                } else {
                    tokenBuffer.append(.greaterThan)
                    advance()
                }
            case "<":
                if position < input.endIndex && input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.lessThanOrEqual)
                    advance(2)
                } else {
                    tokenBuffer.append(.lessThan)
                    advance()
                }
            case "!":
                if position < input.endIndex && input[input.index(after: position)] == "=" {
                    tokenBuffer.append(.notEqualTo)
                    advance(2)
                } else {
                    tokenBuffer.append(.not)
                    advance()
                }
            case "&":
                if position < input.endIndex && input[input.index(after: position)] == "&" {
                    tokenBuffer.append(.and)
                    advance(2)
                } else {
                    throw ScanerError.unexpectedChar(char)
                }
            case "|":
                if position < input.endIndex && input[input.index(after: position)] == "|" {
                    tokenBuffer.append(.or)
                    advance(2)
                } else {
                    throw ScanerError.unexpectedChar(char)
                }
            default:
                if let keyword = scanKeyword() {
                    tokenBuffer.append(keyword)
                } else if let type = scanType() {
                    tokenBuffer.append(type)
                } else if let value = try scanValue() {
                    tokenBuffer.append(value)
                } else if let identifier = scanIdentifier() {
                    tokenBuffer.append(.identifier(identifier))
                } else {
                    throw ScanerError.unexpectedChar(char)
                }
            }
        }

        if !tokenBuffer.isEmpty {
            tokens.append(.line(tokenBuffer))
        }

        return DullToken.root(tokens)
    }


    //MARK: - Helper functions

    func advance(_ steps: Int = 1) {
        for _ in 0..<steps {
            guard position != input.endIndex else { return }
            if input[position] == "\n" {
                lineNumber += 1
            }
            position = input.index(after: position)
        }
    }

    func scanKeyword() -> DullToken? {
        if input[position...].starts(with: "let") {
            position = input.index(position, offsetBy: "let".count)
            return .letKeyword
        } else if input[position...].starts(with: "var") {
            position = input.index(position, offsetBy: "var".count)
            return .varKeyword
        } else if input[position...].starts(with: "func") {
            position = input.index(position, offsetBy: "func".count)
            return .fnKeyword
        } else if input[position...].starts(with: "swift") {
            position = input.index(position, offsetBy: "swift".count)
            return .swiftKeyword
        } else if input[position...].starts(with: "return") {
            position = input.index(position, offsetBy: "return".count)
            return .returnKeyword
        } else if input[position...].starts(with: "if") {
            position = input.index(position, offsetBy: "if".count)
            return .ifKeyword
        } else if input[position...].starts(with: "else") {
            position = input.index(position, offsetBy: "else".count)
            return .elseKeyword
        } else if input[position...].starts(with: "while") {
            position = input.index(position, offsetBy: "while".count)
            return .whileKeyword
        } else if input[position...].starts(with: "guard") {
            position = input.index(position, offsetBy: "guard".count)
            return .guardKeyword
        } else {
            return nil
        }
    }

    func scanType() -> DullToken? {
        let validTypes: [any DullType] = [DullStringType(), DullIntType(), DullAnyType(), DullVoidType(), DullDoubleType(), DullBoolType()]

        for type in validTypes {
            if input[position...].starts(with: type.typeIdentifier) {
                position = input.index(position, offsetBy: type.typeIdentifier.count)
                return .type(.init(type: type))
            }
        }

        return nil
    }

    func scanIdentifier() -> String? {
        let isLetter: (Character) -> Bool = { char in
            return (char >= "a" && char <= "z") || (char >= "A" && char <= "Z") || char == "_"
        }

        let isDigit: (Character) -> Bool = { char in
            return char >= "0" && char <= "9"
        }

        let isIdentifierChar: (Character) -> Bool = { char in
            return isLetter(char) || isDigit(char)
        }

        if isLetter(input[position]) {
            var end = input.index(after: position)

            while end < input.endIndex && isIdentifierChar(input[end]) {
                end = input.index(after: end)
            }

            let identifier = String(input[position..<end])
            position = end

            return identifier
        }

        return nil
    }

    func scanValue() throws -> DullToken? {
        let isDigit: (Character) -> Bool = { char in
            return char >= "0" && char <= "9"
        }

        let isStringDelimiter: (String, String.Index) -> Bool = { (str, index) in
            if str[index] == "\"" {
                if index > str.startIndex && str.index(before: index) >= str.startIndex {
                    if str[str.index(before: index)] == "\\" {
                        return false
                    }
                }

                return true
            } else {
                return false
            }
        }

        let isDot: (Character) -> Bool = { char in
            return char == "."
        }

        let isMinus: (Character) -> Bool = { char in
            return char == "-"
        }

        var isNegative = false
        if isMinus(input[position]) {
            let nextPosition = input.index(after: position)
            if nextPosition < input.endIndex && isDigit(input[nextPosition]) {
                isNegative = true
                position = nextPosition
            }
        }

        if isDigit(input[position]) {
            var end = input.index(after: position)
            var isFloat = false

            while end < input.endIndex && (isDigit(input[end]) || isDot(input[end])) {
                if isDot(input[end]) {
                    if isFloat {
                        throw ScanerError.multipleDotsFound
                    }

                    isFloat = true
                }

                end = input.index(after: end)
            }

            var value = String(input[position..<end])
            position = end

            if isNegative {
                value = "-" + value
            }

            if isFloat {
                guard let dullValue = DullDouble.create(from: value) else {
                    throw ScanerError.unexpectedValue
                }
                return .value(.init(value: dullValue))
            } else {
                guard let dullValue = DullInt.create(from: value) else {
                    throw ScanerError.unexpectedValue
                }
                return .value(.init(value: dullValue))
            }
        } else if isStringDelimiter(input, position) {
            let start = input.index(after: position)
            var end = start

            while end < input.endIndex && !isStringDelimiter(input, end) {
                end = input.index(after: end)
            }

            guard end < input.endIndex else {
                throw ScanerError.unclosedStringLiteral
            }

            let rawValue = String(input[start..<end])
            let value = decodeEscapedCharacters(rawValue) // Decode escaped characters
            position = input.index(after: end)

            guard let dullValue = DullString.create(from: value) else {
                throw ScanerError.unexpectedValue
            }

            return .value(.init(value: dullValue))
        } else if input[position...].starts(with: "true") {
            let end = input.index(position, offsetBy: 4, limitedBy: input.endIndex) ?? input.endIndex
            let value = String(input[position..<end])
            position = end

            guard let dullValue = DullBool.create(from: value) else {
                throw ScanerError.unexpectedValue
            }

            return .value(.init(value: dullValue))
        } else if input[position...].starts(with: "false") {
            let end = input.index(position, offsetBy: 5, limitedBy: input.endIndex) ?? input.endIndex
            let value = String(input[position..<end])
            position = end

            guard let dullValue = DullBool.create(from: value) else {
                throw ScanerError.unexpectedValue
            }

            return .value(.init(value: dullValue))
        }

        return nil
    }

    func decodeEscapedCharacters(_ input: String) -> String {
        var decoded = ""
        var iterator = input.makeIterator()

        while let char = iterator.next() {
            if char == "\\" {
                if let nextChar = iterator.next() {
                    switch nextChar {
                    case "n":
                        decoded.append("\n")
                    case "t":
                        decoded.append("\t")
                    case "\\":
                        decoded.append("\\")
                    case "\"":
                        decoded.append("\"")
                    default:
                        decoded.append(char)
                        decoded.append(nextChar)
                    }
                } else {
                    decoded.append(char)
                }
            } else {
                decoded.append(char)
            }
        }

        return decoded
    }
}
