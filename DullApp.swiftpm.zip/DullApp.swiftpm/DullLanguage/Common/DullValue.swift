//
//  DullValue.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

struct DullValueHolder: Equatable {
    static func == (lhs: DullValueHolder, rhs: DullValueHolder) -> Bool {
        lhs.value.hashValue == rhs.value.hashValue
    }

    let value: any DullValue
}

protocol DullValue: Hashable {
    static func create(from str: String) -> Self?
    var type: any DullType { get }
    var valueString: String { get }
}

struct DullString: DullValue {
    var valueString: String {
        encodeEscapedCharacters(value)
    }

    static func == (lhs: DullString, rhs: DullString) -> Bool {
        lhs.value == rhs.value
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(value)
    }

    static func create(from str: String) -> DullString? {
        return DullString(value: str)
    }

    let value: String
    var type: any DullType = DullStringType()

    func encodeEscapedCharacters(_ input: String) -> String {
        var encoded = ""

        for char in input {
            switch char {
            case "\n":
                encoded.append("\\n")
            case "\t":
                encoded.append("\\t")
            case "\\":
                encoded.append("\\\\")
            case "\"":
                encoded.append("\\\"")
            default:
                encoded.append(char)
            }
        }

        return encoded
    }
}

struct DullInt: DullValue {
    var valueString: String {
        "\(value)"
    }

    static func == (lhs: DullInt, rhs: DullInt) -> Bool {
        lhs.value == rhs.value
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(value)
    }

    static func create(from str: String) -> DullInt? {
        guard let int = Int(str) else { return nil }
        return DullInt(value: int)
    }

    let value: Int
    var type: any DullType = DullIntType()
}

struct DullDouble: DullValue {
    var valueString: String {
        String(format: "%.1f", value)
    }

    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.value == rhs.value
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(value)
    }

    static func create(from str: String) -> Self? {
        guard let double = Double(str) else { return nil }
        return DullDouble(value: double)
    }

    var type: any DullType = DullDoubleType()

    let value: Double
}

struct DullBool: DullValue {
    var valueString: String {
        "\(value)"
    }

    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.value == rhs.value
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(value)
    }

    static func create(from str: String) -> Self? {
        if str == "true" {
            return DullBool(value: true)
        } else if str == "false" {
            return DullBool(value: false)
        } else {
            return nil
        }
    }

    var type: any DullType = DullBoolType()

    let value: Bool
}

struct DullVoid: DullValue {
    var valueString: String {
        "()"
    }

    var type: any DullType = DullVoidType()

    static func == (lhs: DullVoid, rhs: DullVoid) -> Bool {
        true
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(0)
    }

    static func create(from str: String) -> DullVoid? {
        if str == "()" {
            return DullVoid()
        } else {
            return nil
        }
    }
}
