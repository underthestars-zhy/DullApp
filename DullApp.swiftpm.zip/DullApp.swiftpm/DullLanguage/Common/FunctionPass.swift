//
//  FunctionPass.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

struct FunctionPass {
    let underline: Bool
    let name: String
    let type: any DullType
}

struct FunctionPassWrapper {
    let pass: FunctionPass
    let value: any DullValue
}
