//
//  DullType.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

struct DullTypeHolder: Equatable {
    static func == (lhs: DullTypeHolder, rhs: DullTypeHolder) -> Bool {
        lhs.type.hashValue == rhs.type.hashValue
    }

    let type: any DullType
}

protocol DullType: Hashable, Equatable {
    var typeIdentifier: String { get }
}

struct DullStringType: DullType {
    let typeIdentifier: String = "String"
}

struct DullIntType: DullType {
    let typeIdentifier: String = "Int"
}

struct DullAnyType: DullType { // Special
    let typeIdentifier: String = "Any"
}

struct DullVoidType: DullType { // Special
    let typeIdentifier: String = "Void"
}

struct DullDoubleType: DullType {
    let typeIdentifier: String = "Double"
}

struct DullBoolType: DullType {
    let typeIdentifier: String = "Bool"
}


