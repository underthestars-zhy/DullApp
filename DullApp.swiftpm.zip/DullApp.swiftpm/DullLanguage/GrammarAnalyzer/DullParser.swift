//
//  DullParser.swift
//  
//
//  Created by 朱浩宇 on 2023/4/4.
//

import Foundation

class DullParser {
    let token: DullToken

    init(token: DullToken) {
        self.token = token
    }

    func parse() -> DullGrammarType {
        guard case .root(let tokens) = token else {
            fatalError("The token must be of type .root")
        }

        return .root(parseLines(tokens))
    }

    private func parseLines(_ tokens: [DullToken]) -> [DullGrammarType] {
        var grammar: [DullGrammarType] = []

        for lineToken in tokens {
            guard case .line(let lineTokens) = lineToken else { continue }

            if lineTokens.contains(.varKeyword) {
                if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                   case .type(let type) = lineTokens.first(where: { if case .type(_) = $0 { return true } else { return false } }) {
                    grammar.append(.defineVariable(name: name, type: type.type))
                }

                if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                   let equalIndex = lineTokens.firstIndex(of: .equal),
                   equalIndex < lineTokens.count - 1 {

                    if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens, indexBefore: equalIndex) {
                        grammar.append(.setValue(name: name, value: subGrammar))
                    } else {
                        break
                    }
                }
            } else if lineTokens.contains(.letKeyword) {
                if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                   case .type(let type) = lineTokens.first(where: { if case .type(_) = $0 { return true } else { return false } }) {
                    grammar.append(.defineConstant(name: name, type: type.type))
                }

                if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                   let equalIndex = lineTokens.firstIndex(of: .equal),
                   equalIndex < lineTokens.count - 1 {

                    if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens, indexBefore: equalIndex) {
                        grammar.append(.setValue(name: name, value: subGrammar))
                    } else {
                        break
                    }
                }
            } else if lineTokens.contains(.fnKeyword) {
                if case .identifier(let functionName) = lineTokens[1],
                   case .leftParenthesis = lineTokens[2] {

                    var index = lineTokens.firstIndex(of: .rightParenthesis)!
                    var passValueTypes: [FunctionPass] = []

                    while index != lineTokens.firstIndex(of: .leftParenthesis)! {
                        if case .identifier(let paramName) = lineTokens[index - 3],
                           case .type(let paramType) = lineTokens[index - 1] {
                            if (lineTokens[index - 4] == .comma || lineTokens[index - 4] == .leftParenthesis) {
                                passValueTypes.append(.init(underline: false, name: paramName, type: paramType.type))
                                index -= 4
                            } else if (lineTokens[index - 4] == .underscore) {
                                passValueTypes.append(.init(underline: true, name: paramName, type: paramType.type))
                                index -= 5
                            } else {
                                break
                            }
                        } else {
                            break
                        }
                    }

                    passValueTypes.reverse()

                    if case .arrow = lineTokens[lineTokens.firstIndex(of: .rightParenthesis)! + 1],
                       case .type(let returnType) = lineTokens[lineTokens.firstIndex(of: .rightParenthesis)! + 2],
                       case .leftBrace = lineTokens[lineTokens.firstIndex(of: .rightParenthesis)! + 3],
                       case .rightBrace = lineTokens.last {

                        let scopeStartIndex = lineTokens.firstIndex(of: .leftBrace)! + 1
                        let scopeEndIndex = lineTokens.firstIndex(of: .rightBrace)!
                        if case .scope(let scopeTokens) = Array(lineTokens[scopeStartIndex..<scopeEndIndex]).first {
                            let scopeGrammar = parseLines(scopeTokens)

                            grammar.append(.defineFunction(name: functionName, passValueType: passValueTypes, returnType: returnType.type, scope: scopeGrammar))
                        }
                    }
                }
            } else if lineTokens.contains(.returnKeyword) {
                guard let returnIndex = lineTokens.firstIndex(of: .returnKeyword) else { break }

                if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens, indexBefore: returnIndex) {
                    grammar.append(.returnValue(subGrammar))
                }
            } else if lineTokens.contains(.ifKeyword) {
                let (conditions, scopes, elseScope, _) = parseIfElseStatement(tokens: lineTokens, startingAt: 0)
                grammar.append(.ifElse(conditions: conditions, scopes: scopes, elseScope: elseScope))
            } else if lineTokens.contains(.guardKeyword) {
                guard let elseIndex = lineTokens.firstIndex(of: .elseKeyword) else { break }
                guard let guardIndex = lineTokens.firstIndex(of: .guardKeyword) else { break }
                guard let firstBraceIndex = lineTokens.firstIndex(of: .leftBrace) else { break }
                if let condition = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: guardIndex)..<elseIndex].map{ $0 }, indexBefore: -1) {
                    if case .scope(let scopeTokens) = lineTokens[lineTokens.index(after: firstBraceIndex)] {
                        let scope = parseLines(scopeTokens)
                        grammar.append(.guardAction(condition: condition, scope: scope))
                    }
                }
            } else if lineTokens.contains(.whileKeyword) {
                if lineTokens.first == .whileKeyword {
                    guard let firstBraceIndex = lineTokens.firstIndex(of: .leftBrace) else { break }
                    guard let firstWhileIndex = lineTokens.firstIndex(of: .whileKeyword) else { break }

                    if let condition = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: firstWhileIndex)..<firstBraceIndex].map{ $0 }, indexBefore: -1) {
                        if case .scope(let scopeTokens) = lineTokens[lineTokens.index(after: firstBraceIndex)] {
                            let scope = parseLines(scopeTokens)
                            grammar.append(.whileAction(condition: condition, scope: scope))
                        }
                    }
                }
            } else { // No Keyword Case
                if let nameIndex = lineTokens.firstIndex(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                   let equalIndex = lineTokens.firstIndex(where: { if case .equal = $0 { return true } else { return false } }),
                   equalIndex == nameIndex + 1{
                    if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                       let equalIndex = lineTokens.firstIndex(of: .equal),
                       equalIndex < lineTokens.count - 1 {

                        if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: equalIndex)...].map { $0 }, indexBefore: -1) {
                            grammar.append(.setValue(name: name, value: subGrammar))
                        } else {
                            break
                        }
                    }
                } else if let nameIndex = lineTokens.firstIndex(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                          let equalIndex = lineTokens.firstIndex(where: { if case .plusEqual = $0 { return true } else { return false } }),
                          equalIndex == nameIndex + 1{
                    if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                       let equalIndex = lineTokens.firstIndex(of: .plusEqual),
                       equalIndex < lineTokens.count - 1 {

                        if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: equalIndex)...].map { $0 }, indexBefore: -1) {
                            grammar.append(.setValue(name: name, value: .plus(value1: .identifier(name), value2: subGrammar)))
                        } else {
                            break
                        }
                    }
                } else if let nameIndex = lineTokens.firstIndex(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                          let equalIndex = lineTokens.firstIndex(where: { if case .minusEqual = $0 { return true } else { return false } }),
                          equalIndex == nameIndex + 1{
                    if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                       let equalIndex = lineTokens.firstIndex(of: .minusEqual),
                       equalIndex < lineTokens.count - 1 {

                        if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: equalIndex)...].map { $0 }, indexBefore: -1) {
                            grammar.append(.setValue(name: name, value: .minus(value1: .identifier(name), value2: subGrammar)))
                        } else {
                            break
                        }
                    }
                } else if let nameIndex = lineTokens.firstIndex(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                          let equalIndex = lineTokens.firstIndex(where: { if case .multiplyEqual = $0 { return true } else { return false } }),
                          equalIndex == nameIndex + 1{
                    if case .identifier(let name) = lineTokens.first(where: { if case .identifier(_) = $0 { return true } else { return false } }),
                       let equalIndex = lineTokens.firstIndex(of: .multiplyEqual),
                       equalIndex < lineTokens.count - 1 {

                        if let subGrammar = parseValuePlaceholder(lineTokens: lineTokens[lineTokens.index(after: equalIndex)...].map { $0 }, indexBefore: -1) {
                            grammar.append(.setValue(name: name, value: .multiply(value1: .identifier(name), value2: subGrammar)))
                        } else {
                            break
                        }
                    }
                } else if case .identifier(let functionName) = lineTokens.first,
                          case .leftParenthesis = lineTokens[1] {
                    let passValue = lineTokens[2..<(lineTokens.endIndex - 1)].map { $0 }
                    let (passValues, _) = parsePassValues(from: passValue, startingAt: 0)
                    grammar.append(.callFunction(name: functionName, passValue: passValues))
                }
            }
        }

        return grammar
    }

    // MARK: - Helper

    func findEndIndexOfFunctionPass(lineTokens: [DullToken], startIndex: Int) -> Int {
        var index = startIndex
        var parenLevel = 0

        while index <= lineTokens.endIndex {
            if lineTokens[index] == .leftParenthesis {
                parenLevel += 1
            } else if lineTokens[index] == .rightParenthesis {
                parenLevel -= 1
            }

            if parenLevel == 0 {
                return index
            }

            index += 1
        }

        return lineTokens.endIndex
    }

    func parseValuePlaceholder(lineTokens: [DullToken], indexBefore: Int) -> DullGrammarType? {
        var index = 0
        if indexBefore != -1 {
            index = lineTokens.index(after: indexBefore)
        }

        func parseValue(at index: inout Int, lineTokens: [DullToken]) -> DullGrammarType? {
            let valueOrFunctionOrIdentifier = lineTokens[index]

            switch valueOrFunctionOrIdentifier {
            case .value(let value):
                index += 1
                return .value(value.value)
            case .identifier(let identifierOrFunctionName):
                if index + 1 < lineTokens.endIndex && lineTokens[index + 1] == .leftParenthesis {
                    let passValuesStartIndex = index + 1
                    let endIndex = findEndIndexOfFunctionPass(lineTokens: lineTokens, startIndex: passValuesStartIndex)

                    let passValue = (passValuesStartIndex + 1 != endIndex) ? lineTokens[(passValuesStartIndex+1)...(endIndex-1)].map { $0 } : []
                    let (passValues, _) = parsePassValues(from: passValue, startingAt: 0)

                    index += (endIndex - passValuesStartIndex + 1)
                    if index < (lineTokens.endIndex - 1) { index += 1 }
                    return .callFunction(name: identifierOrFunctionName, passValue: passValues)
                } else {
                    index += 1
                    return .identifier(identifierOrFunctionName)
                }
            default:
                return nil
            }
        }

        func parsePrimaryExpression() -> DullGrammarType? {
            if index >= lineTokens.count {
                return nil
            }

            if lineTokens[index] == .leftParenthesis {
                index += 1
                let innerExpression = parseExpression()
                if lineTokens[index] == .rightParenthesis {
                    index += 1

                    // Check if the inner expression is a value and return it directly
                    if case .value(_) = innerExpression {
                        return innerExpression
                    }

                    // Check if the inner expression is a function call and return it directly
                    if case .callFunction(_, _) = innerExpression {
                        return innerExpression
                    }

                    return innerExpression
                } else {
                    return nil // Error: Unbalanced parentheses
                }
            } else {
                return parseValue(at: &index, lineTokens: lineTokens)
            }
        }


        func parseMultiplicativeExpression() -> DullGrammarType? {
            var left = parsePrimaryExpression()

            while index < lineTokens.count {
                let op: DullGrammarType
                if lineTokens[index] == .multiply {
                    op = .multiply(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .divide {
                    op = .divide(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else {
                    break
                }

                let right = parsePrimaryExpression()
                if let rightValue = right {
                    left = op.withUpdatedValue2(rightValue)
                } else {
                    break
                }
            }

            return left
        }

        func parseRelationalExpression() -> DullGrammarType? {
            var left = parseAdditiveExpression()

            while index < lineTokens.count {
                let op: DullGrammarType
                if lineTokens[index] == .greaterThan {
                    op = .greaterThan(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .lessThan {
                    op = .lessThan(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .greaterThanOrEqual {
                    op = .greaterThanOrEqual(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .lessThanOrEqual {
                    op = .lessThanOrEqual(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else {
                    break
                }

                let right = parseAdditiveExpression()
                if let rightValue = right {
                    left = op.withUpdatedValue2(rightValue)
                } else {
                    break
                }
            }

            return left
        }

        func parseEqualityExpression() -> DullGrammarType? {
            var left = parseRelationalExpression()

            while index < lineTokens.count {
                let op: DullGrammarType
                if lineTokens[index] == .equalTo {
                    op = .equalTo(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .notEqualTo {
                    op = .notEqualTo(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else {
                    break
                }

                let right = parseRelationalExpression()
                if let rightValue = right {
                    left = op.withUpdatedValue2(rightValue)
                } else {
                    break
                }
            }

            return left
        }

        func parseAdditiveExpression() -> DullGrammarType? {
            var left = parseMultiplicativeExpression()

            while index < lineTokens.count {
                let op: DullGrammarType
                if lineTokens[index] == .plus {
                    op = .plus(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else if lineTokens[index] == .minus {
                    op = .minus(value1: left!, value2: DullGrammarType.placeholder)
                    index += 1
                } else {
                    break
                }

                let right = parseMultiplicativeExpression()
                if let rightValue = right {
                    left = op.withUpdatedValue2(rightValue)
                } else {
                    break
                }
            }

            return left
        }

        func parseLogicalExpression() -> DullGrammarType? {
                var left = parseEqualityExpression()

                while index < lineTokens.count {
                    let op: DullGrammarType
                    if lineTokens[index] == .and {
                        op = .and(value1: left!, value2: DullGrammarType.placeholder)
                        index += 1
                    } else if lineTokens[index] == .or {
                        op = .or(value1: left!, value2: DullGrammarType.placeholder)
                        index += 1
                    } else if lineTokens[index] == .not {
                        op = .not(value: DullGrammarType.placeholder)
                        index += 1
                    } else {
                        break
                    }

                    let right = parseEqualityExpression()
                    if let rightValue = right {
                        left = op.withUpdatedValue2(rightValue)
                    } else {
                        break
                    }
                }

                return left
            }

        func parseExpression() -> DullGrammarType? {
            return parseLogicalExpression()
        }

        return parseExpression()
    }

    func parsePassValues(from tokens: [DullToken], startingAt startIndex: Int) -> (passValues: [DullGrammarType], endIndex: Int) {
        var index = startIndex
        var passValues: [DullGrammarType] = []
        var parenLevel = 0
        var valueStartIndex = startIndex

        // 将 tokens 用非括号内的逗号分开
        var separatedTokenBlocks: [[DullToken]] = []
        for token in tokens {
            if token == .leftParenthesis {
                parenLevel += 1
            } else if token == .rightParenthesis {
                parenLevel -= 1
            }

            if parenLevel == 0 && token == .comma {
                let block = Array(tokens[valueStartIndex..<index])
                separatedTokenBlocks.append(block)
                valueStartIndex = index + 1
            }

            index += 1
        }

        // 添加最后一个区块
        separatedTokenBlocks.append(Array(tokens[valueStartIndex...]))

        // 处理每个区块
        for block in separatedTokenBlocks {
            var subBlock = block
            if block.count >= 2 && block[1] == .colon {
                subBlock = Array(block[2...])
            }

            if let passValue = parseValuePlaceholder(lineTokens: subBlock, indexBefore: -1) {
                passValues.append(passValue)
            }
        }

        return (passValues, index)
    }

    private func parseIfElseStatement(tokens: [DullToken], startingAt index: Int) -> (conditions: [DullGrammarType], scopes: [[DullGrammarType]], elseScope: [DullGrammarType], nextIndex: Int) {
        var conditions: [DullGrammarType] = []
        var scopes: [[DullGrammarType]] = []
        var elseScope: [DullGrammarType] = []
        var currentIndex = index

        while currentIndex < tokens.count {
            let token = tokens[currentIndex]

            if token == .ifKeyword || token == .elseKeyword {
                var condition: DullGrammarType? = nil

                if token == .ifKeyword {
                    guard let firstBraceIndex = tokens[(currentIndex+1)...].firstIndex(of: .leftBrace) else { break }
                    condition = parseValuePlaceholder(lineTokens: tokens[(currentIndex+1)..<firstBraceIndex].map { $0 }, indexBefore: -1)
                    currentIndex += (1 + tokens[(currentIndex+1)..<firstBraceIndex].count) // skip the if keyword and condition
                } else {
                    currentIndex += 1 // skip the else keyword
                }

                if let condition = condition {
                    conditions.append(condition)
                }

                if tokens[currentIndex] == .leftBrace {
                    if case .scope(let scopeTokens) = tokens[currentIndex + 1] {
                        let scope = parseLines(scopeTokens)
                        scopes.append(scope)

                        currentIndex += 3
                    }
                    
                }
            } else {
                break
            }
        }

        if scopes.count > conditions.count {
            elseScope = scopes.removeLast()
        }

        return (conditions: conditions, scopes: scopes, elseScope: elseScope, nextIndex: currentIndex)
    }
}
