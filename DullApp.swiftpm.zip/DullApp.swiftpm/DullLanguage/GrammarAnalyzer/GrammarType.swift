//
//  DulllGrammarType.swift
//  
//
//  Created by 朱浩宇 on 2023/4/4.
//

import Foundation

indirect enum DullGrammarType {
    case root([DullGrammarType])
    case defineVariable(name: String, type: any DullType)
    case setValue(name: String, value: DullGrammarType)
    case defineConstant(name: String, type: any DullType)
    case callFunction(name: String, passValue: [DullGrammarType])
    case value(any DullValue)
    case identifier(String)
    case defineFunction(name: String, passValueType: [FunctionPass], returnType: any DullType, scope: [DullGrammarType])
    case returnValue(DullGrammarType)
    case plus(value1: DullGrammarType, value2: DullGrammarType)
    case minus(value1: DullGrammarType, value2: DullGrammarType)
    case multiply(value1: DullGrammarType, value2: DullGrammarType)
    case divide(value1: DullGrammarType, value2: DullGrammarType)
    case placeholder
    case greaterThan(value1: DullGrammarType, value2: DullGrammarType)
    case lessThan(value1: DullGrammarType, value2: DullGrammarType)
    case greaterThanOrEqual(value1: DullGrammarType, value2: DullGrammarType)
    case lessThanOrEqual(value1: DullGrammarType, value2: DullGrammarType)
    case equalTo(value1: DullGrammarType, value2: DullGrammarType)
    case notEqualTo(value1: DullGrammarType, value2: DullGrammarType)
    case ifElse(conditions: [DullGrammarType], scopes: [[DullGrammarType]], elseScope: [DullGrammarType])
    case guardAction(condition: DullGrammarType, scope: [DullGrammarType])
    case whileAction(condition: DullGrammarType, scope: [DullGrammarType])
    case and(value1: DullGrammarType, value2: DullGrammarType)
    case or(value1: DullGrammarType, value2: DullGrammarType)
    case not(value: DullGrammarType)
}

extension DullGrammarType {
    func withUpdatedValue2(_ newValue: DullGrammarType) -> DullGrammarType {
        switch self {
        case .plus(let value1, _):
            return .plus(value1: value1, value2: newValue)
        case .minus(let value1, _):
            return .minus(value1: value1, value2: newValue)
        case .multiply(let value1, _):
            return .multiply(value1: value1, value2: newValue)
        case .divide(let value1, _):
            return .divide(value1: value1, value2: newValue)
        case .greaterThan(let value1, _):
            return .greaterThan(value1: value1, value2: newValue)
        case .lessThan(let value1, _):
            return .lessThan(value1: value1, value2: newValue)
        case .greaterThanOrEqual(let value1, _):
            return .greaterThanOrEqual(value1: value1, value2: newValue)
        case .lessThanOrEqual(let value1, _):
            return .lessThanOrEqual(value1: value1, value2: newValue)
        case .equalTo(let value1, _):
            return .equalTo(value1: value1, value2: newValue)
        case .notEqualTo(let value1, _):
            return .notEqualTo(value1: value1, value2: newValue)
        case .and(let value1, _):
            return .and(value1: value1, value2: newValue)
        case .or(let value1, _):
            return .or(value1: value1, value2: newValue)
        case .not:
            return .not(value: newValue)
        default:
            return self
        }
    }
}
