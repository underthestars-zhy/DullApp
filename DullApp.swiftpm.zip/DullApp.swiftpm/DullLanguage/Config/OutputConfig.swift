//
//  OutputConfig.swift
//  
//
//  Created by 朱浩宇 on 2023/4/16.
//

import Foundation

public struct OutputConfig: DullConfig {
    let action: (String) -> ()

    public init(_ action: @escaping (String) -> ()) {
        self.action = action
    }

    public var name: String = "output"

    public func run(_ value: Any) {
        if let str = value as? String {
            action(str)
        } else {
            action("\(value)")
        }
    }
}
