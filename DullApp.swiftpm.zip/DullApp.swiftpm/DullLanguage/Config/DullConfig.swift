//
//  DullConfig.swift
//  
//
//  Created by 朱浩宇 on 2023/4/16.
//

import Foundation

public protocol DullConfig {
    var name: String { get }

    func run(_ value: Any)
}

func findConfig(name: String, in configs: [DullConfig]) -> DullConfig? {
    for config in configs {
        if config.name == name {
            return config
        }
    }

    return nil
}
