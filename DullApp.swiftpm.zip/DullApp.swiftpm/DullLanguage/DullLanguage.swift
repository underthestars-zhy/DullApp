public struct DullLanguage {
    public static let shared = DullLanguage()

    public func run(code: String, config: [DullConfig] = []) throws {
        let tokens = try DullScaner(input: code).scan()
        let grammar = DullParser(token: tokens).parse()
        try DullProcessor(grammar: grammar, config: config).process()
    }

    func preRun(code: String, config: [DullConfig] = []) throws -> DullScope {
        let tokens = try DullScaner(input: code).scan()
        let grammar = DullParser(token: tokens).parse()
        let mainScope = DullScope(label: "main", config: config)
        let _ = try DullProcessor(grammar: grammar, config: config)._process(scope: mainScope)

        return mainScope
    }

    func runWithScope(code: String, config: [DullConfig] = [], scope: DullScope) throws {
        let tokens = try DullScaner(input: code).scan()
        let grammar = DullParser(token: tokens).parse()
        let mainScope = scope
        mainScope.updateScope(config)
        let _ = try DullProcessor(grammar: grammar, config: config)._process(scope: mainScope)
    }
}
