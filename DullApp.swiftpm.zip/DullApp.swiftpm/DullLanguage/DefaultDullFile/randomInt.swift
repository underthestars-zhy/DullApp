//
//  randomInt.swift
//  
//
//  Created by 朱浩宇 on 2023/4/18.
//

import Foundation

func randomInt(pass: [FunctionPassWrapper]) -> any DullValue {
    if pass.count == 2 {
        if let start = pass[0].value as? DullInt, let end = pass[1].value as? DullInt {
            return DullInt(value: Int.random(in: start.value..<end.value))
        }
    }

    return DullVoid()
}
