//
//  print.swift
//  
//
//  Created by 朱浩宇 on 2023/4/6.
//

import Foundation

func dullPrint(pass: [FunctionPassWrapper], config: [DullConfig]) -> any DullValue {
    if let fPass = pass.first, fPass.pass.name == "item" {
        if let dullString = fPass.value as? DullString {
            if let config = findConfig(name: "output", in: config) {
                config.run("\(dullString.value)\n")
            } else {
                print(dullString.value)
            }
        } else if let dullInt = fPass.value as? DullInt {
            if let config = findConfig(name: "output", in: config) {
                config.run("\(dullInt.value)\n")
            } else {
                print(dullInt.value)
            }
        } else if let dullDounle = fPass.value as? DullDouble {
            if let config = findConfig(name: "output", in: config) {
                config.run("\(dullDounle.value)\n")
            } else {
                print(dullDounle.value)
            }
        } else if let dullBool = fPass.value as? DullBool {
            if let config = findConfig(name: "output", in: config) {
                config.run("\(dullBool.value)\n")
            } else {
                print(dullBool.value)
            }
        } else if let _ = fPass.value as? DullVoid {
            if let config = findConfig(name: "output", in: config) {
                config.run("()\n")
            } else {
                print("()")
            }
        }
    }

    return DullVoid()
}
