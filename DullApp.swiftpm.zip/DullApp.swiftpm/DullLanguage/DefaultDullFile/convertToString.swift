//
//  convertToString.swift
//  
//
//  Created by 朱浩宇 on 2023/4/15.
//

import Foundation

func dullConvertToString(pass: [FunctionPassWrapper]) -> any DullValue {
    if let fPass = pass.first, fPass.pass.name == "item" {
        if let dullString = fPass.value as? DullString {
            return dullString
        } else if let dullInt = fPass.value as? DullInt {
            return DullString(value: "\(dullInt.value)")
        } else if let dullDounle = fPass.value as? DullDouble {
            return DullString(value: "\(dullDounle.value)")
        } else if let dullBool = fPass.value as? DullBool {
            return DullString(value: "\(dullBool.value)")
        } else if let _ = fPass.value as? DullVoid {
            return DullString(value: "()")
        }
    }

    return DullString(value: "")
}
