//
//  SwiftFunctionHandle.swift
//  
//
//  Created by 朱浩宇 on 2023/4/6.
//

import Foundation

func SwiftFunctionHandle(_ function: Function, pass: [FunctionPassWrapper], config: [DullConfig]) throws -> any DullValue {
    switch function.name {
    case "print":
        return dullPrint(pass: pass, config: config)
    case "convertToString":
        return dullConvertToString(pass: pass)
    case "randomInt":
        return randomInt(pass: pass)
    default:
        throw ProcessError.unexpectedFunctionName
    }
}
