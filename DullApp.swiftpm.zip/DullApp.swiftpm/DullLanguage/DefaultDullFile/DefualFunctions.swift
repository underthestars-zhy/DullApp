//
//  DefualFunctions.swift
//  
//
//  Created by 朱浩宇 on 2023/4/4.
//

import Foundation

let DefualtFunctions = [
    Function(name: "print", swiftFunction: true, scope: [], pass: [FunctionPass(underline: true, name: "item", type: DullAnyType())], returnType: DullVoidType()),
    Function(name: "convertToString", swiftFunction: true, scope: [], pass: [FunctionPass(underline: true, name: "item", type: DullAnyType())], returnType: DullStringType()),
    Function(name: "randomInt", swiftFunction: true, scope: [], pass: [FunctionPass(underline: false, name: "start", type: DullIntType()), FunctionPass(underline: false, name: "end", type: DullIntType())], returnType: DullIntType()),
]

