//
//  Scope.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

class DullScope {
    let storage: DullStorage
    let label: String
    let parent: DullScope?
    var config: [DullConfig]

    func updateScope(_ config: [DullConfig]) {
        self.config = config
        self.parent?.updateScope(config)
        self.storage.config = config
    }

    init(label: String?, parent: DullScope? = nil, config: [DullConfig]) {
        self.storage = DullStorage(config: config)
        self.label = label ?? UUID().uuidString
        self.parent = parent
        self.config = config
    }

    init(label: String?, preset: [Variable], parent: DullScope? = nil, config: [DullConfig]) {
        self.storage = DullStorage(presetVaribales: preset, config: config)
        self.label = label ?? UUID().uuidString
        self.parent = parent
        self.config = config
    }

    func defineVariable(name: String, type: any DullType) throws {
        try storage.addVaribales(.init(constant: false, name: name, type: type, value: nil))
    }

    func defineConstant(name: String, type: any DullType) throws {
        try storage.addVaribales(.init(constant: true, name: name, type: type, value: nil))
    }

    func setVariableValue(name: String, value: any DullValue) throws {
        do {
            try storage.setVaribalesValue(name, value: value)
        } catch {
            if let parent {
                try parent.setVariableValue(name: name, value: value)
            } else {
                throw error
            }
        }
    }

    func getVariableValue(name: String) throws -> any DullValue {
        do {
            return try storage.getVaribalesValue(name)
        } catch {
            if let parent {
                return try parent.getVariableValue(name: name)
            } else {
                throw error
            }
        }
    }

    func callFunction(name: String, passValue: [any DullValue]) throws -> any DullValue {
        do {
            return try storage.callFunction(name: name, passValue: passValue, scope: self)
        } catch {
            if let parent {
                return try parent.callFunction(name: name, passValue: passValue)
            } else {
                throw error
            }
        }
    }

    func createFunction(name: String, scope: [DullGrammarType], pass: [FunctionPass], returnType: any DullType) throws {
        try storage.createFunction(name: name, scope: scope, pass: pass, returnType: returnType)
    }

    func runSubScope(scope: [DullGrammarType]) throws -> (any DullValue)? {
        let newScope = DullScope(label: UUID().uuidString, parent: self, config: config)

        let processor = DullProcessor(grammar: .root(scope), config: config)

        return try processor._process(scope: newScope)
    }
}


extension DullScope {
    func haveVaribale(name: String, type: String) -> Bool {
        if let variable = storage.getRawVariable(name), let value = variable.value {
            return !variable.constant && value.type.typeIdentifier == type
        } else {
            if let parent {
                return parent.haveVaribale(name: name, type: type)
            } else {
                return false
            }
        }
    }

    func testValue(name: String, value: some DullValue) -> Bool {
        if let variable = storage.getRawVariable(name), let _value = variable.value {
            return value.type.typeIdentifier == _value.type.typeIdentifier && value.valueString == _value.valueString
        } else {
            if let parent {
                return parent.testValue(name: name, value: value)
            } else {
                return false
            }
        }
    }

    func getRawFunction(name: String) -> Function? {
        if let function = storage.getRawFunction(name) {
            return function
        } else {
            if let parent {
                return parent.getRawFunction(name: name)
            } else {
                return nil
            }
        }
    }
}
