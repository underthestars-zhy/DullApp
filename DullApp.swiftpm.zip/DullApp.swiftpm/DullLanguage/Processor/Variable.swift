//
//  Variable.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

struct Variable {
    let constant: Bool
    let name: String
    let type: any DullType
    let value: (any DullValue)?
}
