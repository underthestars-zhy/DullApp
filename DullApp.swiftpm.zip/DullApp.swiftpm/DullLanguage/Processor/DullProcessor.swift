//
//  DullProcessor.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

class DullProcessor {
    let grammar: DullGrammarType
    let config: [DullConfig]
    
    init(grammar: DullGrammarType, config: [DullConfig] = []) {
        self.grammar = grammar
        self.config = config
    }

    func process() throws {
        let mainScope = DullScope(label: "main", config: config)
        let _ = try _process(scope: mainScope)
    }

    func _process(scope: DullScope) throws -> (any DullValue)? {
        if case .root(let array) = grammar {
            for grammar in array {
                switch grammar {
                case .root:
                    throw ProcessError.unexpectedRoot
                case .defineVariable(let name, let type):
                    try scope.defineVariable(name: name, type: type)
                case .setValue(let name, let value):
                    guard let dullValue = try processGrammarValue(value, scope: scope) else {
                        throw ProcessError.unexpectedValue
                    }

                    try scope.setVariableValue(name: name, value: dullValue)
                case .defineConstant(let name, let type):
                    try scope.defineConstant(name: name, type: type)
                case .callFunction(let name, let passValue):
                    let _ = try callFunction(name: name, passValue: passValue, scope: scope)
                case .value:
                    continue
                case .identifier:
                    continue
                case .defineFunction(let name, let passValueType, let returnType, let fScope):
                    try scope.createFunction(name: name, scope: fScope, pass: passValueType, returnType: returnType)
                case .returnValue(let value):
                    return try processGrammarValue(value, scope: scope)
                case .plus, .minus, .multiply, .divide:
                    continue
                case .placeholder:
                    continue
                case .greaterThan:
                    continue
                case .lessThan:
                    continue
                case .greaterThanOrEqual:
                    continue
                case .lessThanOrEqual:
                    continue
                case .equalTo:
                    continue
                case .notEqualTo:
                    continue
                case .ifElse(conditions: let conditions, scopes: let scopes, elseScope: let elseScope):
                    var useElse = true

                    for (index, condition) in conditions.enumerated() {
                        if let dullBool = try processGrammarValue(condition, scope: scope) as? DullBool, dullBool == DullBool(value: true) {
                            useElse = false

                            if index < scopes.endIndex {
                                let iScope = scopes[index]

                                if let returnValue = try scope.runSubScope(scope: iScope) {
                                    return returnValue
                                }
                            } else {
                                throw ProcessError.unxpectedScope
                            }
                        }
                    }

                    if useElse {
                        if let returnValue = try scope.runSubScope(scope: elseScope) {
                            return returnValue
                        }
                    }
                case .whileAction(condition: let condition, scope: let iScope):
                    while true {
                        if let dullBool = try processGrammarValue(condition, scope: scope) as? DullBool, dullBool == DullBool(value: true) {
                            if let returnValue = try scope.runSubScope(scope: iScope) {
                                return returnValue
                            }
                        } else {
                            break
                        }
                    }
                case .and:
                    continue
                case .or:
                    continue
                case .not:
                    continue
                case .guardAction(condition: let condition, scope: let iScope):
                    if let dullBool = try processGrammarValue(condition, scope: scope) as? DullBool, dullBool == DullBool(value: false) {
                        if let returnValue = try scope.runSubScope(scope: iScope) {
                            return returnValue
                        }
                    }
                }
            }
        } else {
            throw ProcessError.cannotFindMainProgram
        }

        return nil
    }

    func processGrammarValue(_ value: DullGrammarType, scope: DullScope) throws -> (any DullValue)? {
        switch value {
        case .callFunction(let name, let passValue):
            return try callFunction(name: name, passValue: passValue, scope: scope)
        case .value(let dullValue):
            return dullValue
        case .identifier(let string):
            return try scope.getVariableValue(name: string)
        case .plus(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullString1 = dullValue1 as? DullString, let dullString2 = dullValue2 as? DullString {
                    return DullString(value: dullString1.value + dullString2.value)
                } else if let dullInt1 = dullValue1 as? DullInt, let dullInt2 = dullValue2 as? DullInt {
                    return DullInt(value: dullInt1.value + dullInt2.value)
                } else if let dullDouble1 = dullValue1 as? DullDouble, let dullDouble2 = dullValue2 as? DullDouble {
                    return DullDouble(value: dullDouble1.value + dullDouble2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .minus(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullInt1 = dullValue1 as? DullInt, let dullInt2 = dullValue2 as? DullInt {
                    return DullInt(value: dullInt1.value - dullInt2.value)
                } else if let dullDouble1 = dullValue1 as? DullDouble, let dullDouble2 = dullValue2 as? DullDouble {
                    return DullDouble(value: dullDouble1.value - dullDouble2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .multiply(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullInt1 = dullValue1 as? DullInt, let dullInt2 = dullValue2 as? DullInt {
                    return DullInt(value: dullInt1.value * dullInt2.value)
                } else if let dullDouble1 = dullValue1 as? DullDouble, let dullDouble2 = dullValue2 as? DullDouble {
                    return DullDouble(value: dullDouble1.value * dullDouble2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .divide(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullInt1 = dullValue1 as? DullInt, let dullInt2 = dullValue2 as? DullInt {
                    if dullInt2.value == 0 {
                        throw ProcessError.dividedNumberCannotBeZero
                    }
                    return DullInt(value: dullInt1.value / dullInt2.value)
                } else if let dullDouble1 = dullValue1 as? DullDouble, let dullDouble2 = dullValue2 as? DullDouble {
                    if dullDouble2.value == 0 {
                        throw ProcessError.dividedNumberCannotBeZero
                    }

                    return DullDouble(value: dullDouble1.value / dullDouble2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .greaterThan(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value > dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {

                    return DullBool(value: dullRaw1.value > dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value > dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .lessThan(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value < dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {
                    return DullBool(value: dullRaw1.value < dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value < dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .greaterThanOrEqual(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value >= dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {
                    return DullBool(value: dullRaw1.value >= dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value >= dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .lessThanOrEqual(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value <= dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {
                    return DullBool(value: dullRaw1.value <= dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value <= dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .equalTo(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value == dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {
                    return DullBool(value: dullRaw1.value == dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value == dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .notEqualTo(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullString, let dullRaw2 = dullValue2 as? DullString {
                    return DullBool(value: dullRaw1.value != dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullInt, let dullRaw2 = dullValue2 as? DullInt {
                    return DullBool(value: dullRaw1.value != dullRaw2.value)
                } else if let dullRaw1 = dullValue1 as? DullDouble, let dullRaw2 = dullValue2 as? DullDouble {
                    return DullBool(value: dullRaw1.value != dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .and(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullBool, let dullRaw2 = dullValue2 as? DullBool {
                    return DullBool(value: dullRaw1.value && dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .or(value1: let value1, value2: let value2):
            if let dullValue1 = try processGrammarValue(value1, scope: scope),
               let dullValue2 = try processGrammarValue(value2, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullBool, let dullRaw2 = dullValue2 as? DullBool {
                    return DullBool(value: dullRaw1.value || dullRaw2.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        case .not(value: let value):
            if let dullValue1 = try processGrammarValue(value, scope: scope) {
                if let dullRaw1 = dullValue1 as? DullBool{
                    return DullBool(value: !dullRaw1.value)
                } else {
                    throw ProcessError.unexpectedValue
                }
            } else {
                throw ProcessError.unexpectedValue
            }
        default:
            throw ProcessError.unexpectedValue
        }
    }

    func callFunction(name: String, passValue: [DullGrammarType], scope: DullScope) throws -> any DullValue {
        let pass = try passValue.compactMap { value -> (any DullValue)? in
            try processGrammarValue(value, scope: scope)
        }

        return try scope.callFunction(name: name, passValue: pass)
    }
}
