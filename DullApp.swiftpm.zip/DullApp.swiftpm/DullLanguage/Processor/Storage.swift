//
//  Storage.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

class DullStorage {
    private var varibales = [Variable]()
    private var functions = DefualtFunctions
    private var presetVaribales = [Variable]()
    var config: [DullConfig]

    init(presetVaribales: [Variable], config: [DullConfig]) {
        self.varibales = []
        self.functions = DefualtFunctions
        self.presetVaribales = presetVaribales
        self.config = config
    }

    init(config: [DullConfig]) {
        self.varibales = []
        self.functions = DefualtFunctions
        self.presetVaribales = []
        self.config = config
    }
    
    func addVaribales(_ varibale: Variable) throws {
        if self.varibales.map(\.name).contains(varibale.name) {
            throw ProcessError.duplicatedVariableName
        }
        
        varibales.append(varibale)
    }
    
    func setVaribalesValue(_ name: String, value: any DullValue) throws {
        guard let variableIndex = varibales.firstIndex(where: { varia in
            return varia.name == name
        }) else {
            throw ProcessError.undefinedVariable
        }
        
        let variable = varibales[variableIndex]
        
        guard variable.type.typeIdentifier == value.type.typeIdentifier || variable.type.typeIdentifier == DullAnyType().typeIdentifier else {
            throw ProcessError.unmatchValueType
        }

        guard !variable.constant || variable.value == nil else {
            throw ProcessError.setConstantMultipleTimes
        }
        
        let newVariable = Variable(constant: variable.constant, name: variable.name, type: variable.type, value: value)
        
        varibales[variableIndex] = newVariable
    }
    
    func getVaribalesValue(_ name: String) throws -> any DullValue {
        if let variableIndex = presetVaribales.firstIndex(where: { varia in
            varia.name == name
        }) {
            guard let dullValue = presetVaribales[variableIndex].value else {
                throw ProcessError.unassignedValue
            }

            return dullValue
        } else if let variableIndex = varibales.firstIndex(where: { varia in
            varia.name == name
        }) {
            guard let dullValue = varibales[variableIndex].value else {
                throw ProcessError.unassignedValue
            }

            return dullValue
        } else {
            throw ProcessError.undefinedVariable
        }
    }

    func getRawVariable(_ name: String) -> Variable? {
        print(varibales)
        if let variableIndex = presetVaribales.firstIndex(where: { varia in
            varia.name == name
        }) {
            return presetVaribales[variableIndex]
        } else if let variableIndex = varibales.firstIndex(where: { varia in
            varia.name == name
        }) {
            return varibales[variableIndex]
        } else {
            return nil
        }
    }

    func getRawFunction(_ name: String) -> Function? {
        guard let function = functions.first(where: { f in
            f.name == name
        }) else {
            return nil
        }

        return function
    }
    
    func callFunction(name: String, passValue: [any DullValue], scope: DullScope) throws -> any DullValue {
        let parent = scope

        guard let function = functions.first(where: { f in
            f.name == name
        }) else {
            throw ProcessError.unexpectedFunctionName
        }

        guard function.pass.count == passValue.count else { throw ProcessError.passValueCountNotMatch }
        
        let returnValue: any DullValue
        
        let wrappers = zip(passValue, function.pass).map { (value, pass) in
            FunctionPassWrapper(pass: pass, value: value)
        }

        guard wrappers.allSatisfy({ w in
            return w.pass.type.typeIdentifier == w.value.type.typeIdentifier || w.pass.type.typeIdentifier == DullAnyType().typeIdentifier
        }) else {
            throw ProcessError.functionPassTypeUnmatch
        }
        
        if function.swiftFunction {
            returnValue = try SwiftFunctionHandle(function, pass: wrappers, config: config)
        } else {
            let fScope = function.scope

            let passVariables = wrappers.map { w in
                Variable(constant: true, name: w.pass.name, type: w.pass.type, value: w.value)
            }

            let scope = DullScope(label: UUID().uuidString, preset: passVariables, parent: parent, config: config)

            let fProcess = DullProcessor(grammar: .root(fScope))

            guard let _returnValue = try fProcess._process(scope: scope) else {
                throw ProcessError.functionNoReturnValue
            }

            returnValue = _returnValue
        }
        
        guard returnValue.type.typeIdentifier == function.returnType.typeIdentifier || function.returnType.typeIdentifier == "Any" else {
            throw ProcessError.unexpectedFunctionReturnType
        }

        return returnValue
    }

    func createFunction(name: String, scope: [DullGrammarType], pass: [FunctionPass], returnType: any DullType) throws {
        let dullFuncion = Function(name: name, swiftFunction: false, scope: scope, pass: pass, returnType: returnType)

        guard !functions.map(\.name).contains(name) else {
            throw ProcessError.duplicatedFunctionName
        }

        functions.append(dullFuncion)
    }
}
