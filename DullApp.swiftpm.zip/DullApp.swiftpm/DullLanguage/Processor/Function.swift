//
//  Function.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

struct Function {
    let name: String
    let swiftFunction: Bool
    let scope: [DullGrammarType]
    let pass: [FunctionPass]
    let returnType: any DullType
}
