//
//  ProcessError.swift
//  
//
//  Created by 朱浩宇 on 2023/4/5.
//

import Foundation

public enum ProcessError: Error {
    case cannotFindMainProgram
    case unexpectedRoot
    case unexpectedValue
    case duplicatedVariableName
    case duplicatedFunctionName
    case undefinedVariable
    case unmatchValueType
    case unexpectedFunctionName
    case unexpectedFunctionReturnType
    case unassignedValue
    case functionPassTypeUnmatch
    case functionNoReturnValue
    case dividedNumberCannotBeZero
    case unxpectedScope
    case setConstantMultipleTimes
    case passValueCountNotMatch
}
