//
//  GrammarView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct GrammarView: View {
    let level: Int
    let grammar: DullGrammarType

    var body: some View {
        LazyVStack(spacing: 0) {
            switch grammar {
            case .root(let array):
                VStack(spacing: 30) {
                    ForEach(array.map({ t in
                        DullGrammarWrapper(grammar: t)
                    })) { grammar in
                        GrammarView(level: level + 1, grammar: grammar.grammar)
                    }
                }
            case .defineVariable(name: let name, type: let type):
                DefaultGrammarView(text: "Define a Variable\nName: \(name)\nType: \(type.typeIdentifier)")
            case .setValue(name: let name, value: let value):
                SubGrammarView(name: "Value:", text: "Set the Value for \(name)", grammars: [value], level: level)
            case .defineConstant(name: let name, type: let type):
                DefaultGrammarView(text: "Define a Constant, Name: \(name), Type: \(type.typeIdentifier)")
            case .callFunction(name: let name, passValue: let passValue):
                SubGrammarView(name: "Pass Values:", text: "Call Function: \(name)", grammars: passValue, level: level)
            case .value(let value):
                DefaultGrammarView(text: "Value: \(value.type.typeIdentifier)(\(value.valueString))")
            case .identifier(let name):
                DefaultGrammarView(text: "Identifier: \(name)")
            case .defineFunction(name: let name, passValueType: let passValueType, returnType: let returnType, scope: let scope):
                VStack(spacing: 0) {
                    HStack(spacing: 0) {
                        Text("Define a Function: \(name)")
                            .font(.system(size: 24, weight: .bold, design: .monospaced))
                            .padding(.leading, 30)
                            .padding(.vertical, 18)

                        Spacer()
                    }
                    .padding(.top, 20)

                    VStack(spacing: 0) {
                        HStack(spacing: 0) {
                            Text("Pass Value:")
                                .font(.system(size: 32, weight: .heavy, design: .monospaced))
                                .padding(.leading, 30)
                                .padding(.horizontal, 20)

                            Spacer()
                        }
                        .padding(.top, 20)

                        LazyVStack(spacing: 30) {
                            ForEach(passValueType.map({ t in
                                UIFunctionPassWrapper(pass: t)
                            })) { pass in
                                DefaultGrammarView(text: "Function Pass:\nHide Label: \(pass.pass.underline)\nName: \(pass.pass.name)\nType: \(pass.pass.type.typeIdentifier)")
                                    .frame(width: 1000 - (60*Double(level+1)))
                                    .frame(minHeight: 60)
                                    .overlay {
                                        if level >= 0 {
                                            RoundedRectangle(cornerRadius: 30)
                                                .stroke(Color.black, lineWidth: 6)
                                        }
                                    }
                            }
                        }
                        .padding(.top, 20)
                    }
                    .padding(.bottom, 30)

                    HStack(spacing: 0) {
                        Text("Return Type: \(returnType.typeIdentifier)")
                            .font(.system(size: 32, weight: .heavy, design: .monospaced))
                            .padding(.leading, 30)
                            .padding(.horizontal, 20)

                        Spacer()
                    }
                    .padding(.top, 20)

                    VStack(spacing: 0) {
                        HStack(spacing: 0) {
                            Text("Scope:")
                                .font(.system(size: 32, weight: .heavy, design: .monospaced))
                                .padding(.leading, 30)
                                .padding(.horizontal, 20)

                            Spacer()
                        }
                        .padding(.top, 20)

                        LazyVStack(spacing: 30) {
                            ForEach(scope.map({ t in
                                DullGrammarWrapper(grammar: t)
                            })) { grammar in
                                GrammarView(level: level + 1, grammar: grammar.grammar)
                            }
                        }
                        .padding(.top, 20)
                    }
                    .padding(.bottom, 30)
                }
            case .returnValue(let value):
                SubGrammarView(name: "Value", text: "Action: Return", grammars: [value], level: level)
            case .plus(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Calculate Operation: Plus", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .minus(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Calculate Operation: Minus", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .multiply(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Calculate Operation: Multiply", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .divide(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Calculate Operation: Divide", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .placeholder:
                DefaultGrammarView(text: "Placeholder: An Error Happen")
            case .greaterThan(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Greater Than", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .lessThan(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Less Than", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .greaterThanOrEqual(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Greater Than or Equal", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .lessThanOrEqual(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Less Than or Euqal", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .equalTo(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Equal To", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .notEqualTo(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Compare Operation: Not Equal To", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .ifElse(conditions: let conditions, scopes: let scopes, elseScope: let elseScope):
                VStack(spacing: 0) {
                    HStack(spacing: 0) {
                        Text("Condition Statement: if-else")
                            .font(.system(size: 24, weight: .bold, design: .monospaced))
                            .padding(.leading, 30)
                            .padding(.vertical, 18)

                        Spacer()
                    }
                    .padding(.top, 20)

                    ForEach(1..<scopes.count, id: \.self) { index in
                        SubGrammarView3(name1: "Condition #\(index + 1)", name2: "Scope #\(index + 1)", grammars1: [conditions[index]], grammars2: scopes[index], level: level)
                    }

                    if !elseScope.isEmpty, let lastCondition = conditions.last {
                        SubGrammarView3(name1: "Condition (else)", name2: "Scope (else)", grammars1: [lastCondition], grammars2: elseScope, level: level)
                    }
                }
            case .guardAction(condition: let condition, scope: let scope):
                SubGrammarView2(text: "Condition Statement: guard", name1: "Condition", name2: "Scope", grammars1: [condition], grammars2: scope, level: level)
            case .whileAction(condition: let condition, scope: let scope):
                SubGrammarView2(text: "Loop Statement: while", name1: "Condition", name2: "Scope", grammars1: [condition], grammars2: scope, level: level)
            case .and(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Logic Operation: and", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .or(value1: let value1, value2: let value2):
                SubGrammarView2(text: "Logic Operation: or", name1: "Value #1", name2: "Value #2", grammars1: [value1], grammars2: [value2], level: level)
            case .not(value: let value):
                SubGrammarView(name: "Value", text: "Logic Operation: not", grammars: [value], level: level)
            }
        }
        .frame(minHeight: 60)
        .frame(width: 1000 - (60*Double(level)))
        .overlay {
            if level >= 0 {
                RoundedRectangle(cornerRadius: 30)
                    .stroke(Color.black, lineWidth: 6)
            }
        }
    }
}

struct SubGrammarView: View {
    let name: String
    let text: String
    let grammars: [DullGrammarType]
    let level: Int

    var body: some View {
        VStack(spacing: 0) {
            if !text.isEmpty {
                HStack(spacing: 0) {
                    Text(text)
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .padding(.leading, 30)

                    Spacer()
                }
                .padding(.top, 20)
            }

            HStack(spacing: 0) {
                Text("\(name)")
                    .font(.system(size: 32, weight: .heavy, design: .monospaced))
                    .padding(.leading, 30)
                    .padding(.horizontal, 20)

                Spacer()
            }
            .padding(.top, 20)

            LazyVStack(spacing: 30) {
                ForEach(grammars.map({ t in
                    DullGrammarWrapper(grammar: t)
                })) { grammar in
                    GrammarView(level: level + 1, grammar: grammar.grammar)
                }
            }
            .padding(.top, 20)
            .padding(.bottom, 30)
        }
    }
}

struct SubGrammarView2: View {
    let text: String

    let name1: String
    let name2: String
    let grammars1: [DullGrammarType]
    let grammars2: [DullGrammarType]
    let level: Int

    var body: some View {
        VStack(spacing: 0) {
            if !text.isEmpty {
                HStack(spacing: 0) {
                    Text(text)
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .padding(.leading, 30)

                    Spacer()
                }
                .padding(.top, 20)
            }

            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Text("\(name1)")
                        .font(.system(size: 32, weight: .heavy, design: .monospaced))
                        .padding(.leading, 30)
                        .padding(.horizontal, 20)

                    Spacer()
                }
                .padding(.top, 20)

                LazyVStack(spacing: 30) {
                    ForEach(grammars1.map({ t in
                        DullGrammarWrapper(grammar: t)
                    })) { grammar in
                        GrammarView(level: level + 1, grammar: grammar.grammar)
                    }
                }
                .padding(.top, 20)
            }
            .padding(.bottom, 30)

            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Text("\(name2)")
                        .font(.system(size: 32, weight: .heavy, design: .monospaced))
                        .padding(.leading, 30)
                        .padding(.horizontal, 20)

                    Spacer()
                }
                .padding(.top, 20)

                LazyVStack(spacing: 30) {
                    ForEach(grammars2.map({ t in
                        DullGrammarWrapper(grammar: t)
                    })) { grammar in
                        GrammarView(level: level + 1, grammar: grammar.grammar)
                    }
                }
                .padding(.top, 20)
            }
            .padding(.bottom, 30)
        }
    }
}

struct SubGrammarView3: View {
    let name1: String
    let name2: String
    let grammars1: [DullGrammarType]
    let grammars2: [DullGrammarType]
    let level: Int

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text(name1)
                    .font(.system(size: 32, weight: .heavy, design: .monospaced))
                    .padding(.leading, 30)
                    .padding(.horizontal, 20)

                Spacer()
            }
            .padding(.top, 20)

            LazyVStack(spacing: 30) {
                ForEach(grammars1.map({ t in
                    DullGrammarWrapper(grammar: t)
                })) { grammar in
                    GrammarView(level: level + 1, grammar: grammar.grammar)
                }
            }
            .padding(.top, 20)
        }
        .padding(.bottom, 30)

        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text(name2)
                    .font(.system(size: 32, weight: .heavy, design: .monospaced))
                    .padding(.leading, 30)
                    .padding(.horizontal, 20)

                Spacer()
            }
            .padding(.top, 20)

            LazyVStack(spacing: 30) {
                ForEach(grammars2.map({ t in
                    DullGrammarWrapper(grammar: t)
                })) { grammar in
                    GrammarView(level: level + 1, grammar: grammar.grammar)
                }
            }
            .padding(.top, 20)
        }
        .padding(.bottom, 30)
    }
}

struct DefaultGrammarView: View {
    let text: String

    var body: some View {
        HStack(spacing: 0) {
            Text(text)
                .font(.system(size: 24, weight: .bold, design: .monospaced))
                .padding(.leading, 30)
                .padding(.vertical, 18)
            Spacer()
        }
        .frame(minHeight: 60)
    }
}

struct DullGrammarWrapper: Identifiable {
    let id = UUID()

    let grammar: DullGrammarType
}

struct UIFunctionPassWrapper: Identifiable {
    let id = UUID()

    let pass: FunctionPass
}
