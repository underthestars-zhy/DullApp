//
//  HomePageTopBar.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import SwiftUI

struct HomePageTopBar: View {
    let imageName: String
    let text: String

    let action: () -> ()
    
    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                BackButton(dark: false) {
                    action()
                }

                Spacer()
            }

            HStack(spacing: 0) {
                Image(systemName: imageName)
                    .font(.system(size: 54))
                    .foregroundColor(.white)

                Text(text)
                    .font(.system(size: 36, weight: .bold, design: .monospaced))
                    .padding(.leading, 30)
                    .foregroundColor(.white)
            }
        }
        .frame(width: 900)
    }
}
