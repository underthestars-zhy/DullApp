//
//  PlaygroundItem.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct PlaygroundItem: View {
    let name: String
    let lastEditedTime: Date
    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(name)
                        .multilineTextAlignment(.leading)
                        .font(.system(size: 21, weight: .heavy, design: .monospaced))
                        .padding(.top, 20)
                        .padding(.leading, 25)

                    HStack {
                        Image(systemName: "lasso.and.sparkles")
                            .font(.system(size: 21))
                            .foregroundColor(.black)

                        Text("Last Edited: \(timeDifference(from: lastEditedTime, to: Date()))")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))

                        Spacer()
                    }
                    .padding(.top, 12)
                    .padding(.leading, 25)

                    Spacer()
                }

                Spacer()
            }
            .frame(width: 260, height: 176)
            .background(.white)
            .cornerRadius(30)
        }
    }

    func timeDifference(from fromDate: Date, to toDate: Date) -> String {
        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fromDate, to: toDate)

        if let year = components.year, year > 0 {
            return "\(year)y"
        } else if let month = components.month, month > 0 {
            return "\(month)m"
        } else if let day = components.day, day > 0 {
            return "\(day)d"
        } else if let hour = components.hour, hour > 0 {
            return "\(hour)h"
        } else if let minute = components.minute, minute > 0 {
            return "\(minute)min"
        } else if let second = components.second, second > 0 {
            return "\(second)s"
        } else {
            return "now"
        }
    }
}
