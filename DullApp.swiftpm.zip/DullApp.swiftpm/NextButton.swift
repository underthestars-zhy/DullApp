//
//  NextButton.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct NextButton: View {
    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                Image(systemName: "arrow.right")
                    .font(.system(size: 36, weight: .semibold))
                    .padding(.leading, 20)
                    .foregroundColor(.white)
                    .padding(.trailing, 7)

                Text("NEXT")
                    .font(.system(size: 24, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(.trailing, 25)
            }
            .frame(height: 60)
            .background(.black)
            .cornerRadius(30)
        }
    }
}
