//
//  PracticeCheckButton.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/18.
//

import SwiftUI

struct PracticeCheckButton: View {
    @Binding var check: Bool
    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                if check {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 18, weight: .semibold))
                        .padding(.leading, 15)
                        .padding(.trailing, 8)

                    Text("PASS")
                        .font(.system(size: 18, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.trailing, 20)
                } else {
                    Image(systemName: "paperplane.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 16))
                        .padding(.leading, 15)
                        .padding(.trailing, 8)

                    Text("CHECK")
                        .font(.system(size: 18, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.trailing, 20)
                }
            }
            .frame(height: 40)
            .background(.black)
            .cornerRadius(20)
        }
    }
}
