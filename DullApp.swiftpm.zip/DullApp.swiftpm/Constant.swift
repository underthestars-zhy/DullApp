//
//  Constant.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import Foundation

let aboutText = """
Dull is a SWIFT-style interpreted programming language written in Swift, which allows it to run on almost all platforms, including iPhone and Apple Watch. It can be imported to any Swift Projects by using SPM (Will Become Open-Sources After Challenge).

By utilizing Dull, developers can create coding education apps more creatively, as they can directly execute the user's code within the app.

Moreover, it becomes much easier for developers to implement a plugin system. All they need to do is import the Dull Language into their app and add the necessary APIs to facilitate interactions.

Currently, the Dull Language is still under heavy development. The primary goal is to support all Swift features, and subsequently, introduce some unique functions.
"""

let documentations = [
    Documentation(title: "Types in the Dull Language & Print", index: 1, practice: false, fullText: #"""
Dull Language currently supports only a few types: String, Boolean, Integer, Decimal, and Void.

The String type is represented by the keyword "String" in Dull. It can hold various values, such as "hi, dull" and "I am Ryan". All text values should be enclosed in quotes. The string type also supports special characters such as:

1. New Line: \n
2. Tab: \t
3. Backslash(\): \\
4. Quotation marks(“): \”

dull>print("Hi \"I\" am\nDull Language")

The Boolean type is represented by the keyword "Bool" in Dull. It only has two possible values: true and false.

dull>print(true)

The Integer type is represented by the keyword "Int" in Dull. It can hold various integer values, such as 1, -1, and 20. This type can store integers between -2,147,483,648 and 2,147,483,647.

dull>print(13456)

The Decimal type is represented by the keyword "Double" in Dull. It can hold various decimal values, such as 1.0, -2.3, and 12.56. This type can store decimals between -1.7976931348623157e+308 and 1.7976931348623157e+308. In Dull, all decimals are double precision.

dull>print(-1.45)

The Void type is represented by the keyword "Void" in Dull. It only has one possible value, (), which is typically used as the return type in functions that don't have a return value.

dull>print(())

The Any type is a very special type, it isn't a typical type. It can be any type. Making people confused.

In the code above, we use function "print" to output, which means let it show on the screen. In the Dull, the "print" function is capable of printing values of any type.
"""#),
    Documentation(title: "Define & Set Constants and Variables", index: 2, practice: false, fullText: #"""
In the Dull Language, values can be stored in Constants and Variables. Once a constant or variable is defined and its value is set, it can be retrieved by its assigned name.

It is important to note that Constants and Variables have a slight difference - constants can only be assigned a value once, while variables have no such limitation.

When defining a constant or variable in Dull, it is necessary to specify its name and data type. The "let" keyword is used to define a constant, whereas the "var" keyword is used for a variable.

dull>let stringConstant: String
dull>var intVaribale: Int

Assigning values to constants and variables is a straightforward process in Dull - the "=" symbol is used to set the value. It is crucial to ensure that the type of the value being assigned matches the data type of the constant or variable being defined.

dull>stringConstant = "hello, dull"
dull>intVaribale = 1245
dull>print(stringConstant)
dull>print(intVaribale)

In addition, Dull provides a convenient way to define and set the value of a variable or constant in a single line.

dull>let doubleConstant: Double = 1.2
dull>var boolVaribale: Bool = true
dull>print(doubleConstant)
dull>print(boolVaribale)

Do you still remember the Any type we talked about in the last section? I am going to show a use case of it.

dull>var any: Any = 1.2
dull>print(any)
dull>any = "hello, I am MAGICAL any"
dull>print(any)
"""#),
    Documentation(title: "Practice #1", index: 3, practice: true,practices: [
        .init(code: "", evaluation: { aboveCode, code in
            let scope = try DullLanguage.shared.preRun(code: aboveCode)
            try DullLanguage.shared.runWithScope(code: code, config: [], scope: scope)
            return scope.haveVaribale(name: "myFirstVariable", type: "String")
        }),
        .init(code: "", evaluation: { aboveCode, code in
            var result = ""
            let config = [OutputConfig({ str in
                result += str
            })]
            let scope = try DullLanguage.shared.preRun(code: aboveCode)
            try DullLanguage.shared.runWithScope(code: code, config: config, scope: scope)
            if let value = try? scope.getVariableValue(name: "myFirstVariable") as? DullString {
                return value.value + "\n" == result
            } else {
                return false
            }
        })
    ], fullText: #"""
This is a practice exercise that requires you to follow the provided guidelines to complete it.

Firstly, you are required to create a variable named "myFirstVariable", with its type set as a string. It should also be assigned a random initial value.

practice>0

Secondly, you should proceed to print the variable that you have just created.

practice>1
"""#),
    Documentation(title: "Define & Call Functions", index: 4, practice: false, fullText: #"""
In Dull Language, functions can be defined to perform code on input values and return output values. Functions are useful for performing repetitive tasks and simplifying code.

Functions in Dull Language are made up of four parts: a name, a list of input value types, code to be executed, and a return type. Input values can be absent or present in multiple types. The code is what the function will perform when it is called. The return type indicates the type of the value that the function will generate after executing the inner code.

dull>func hello(text: String) -> String { return "Hello :) " + text }
dull>func dull() -> Void {}

Input values have labels, which can be used in both function calls and inner code. The inner code will refer to these labels as the name of a constant.

dull>func labeledFunc(a: Int, b: String) -> String {
dull>   print(a)
dull>   return b
dull>}

Dull Language also supports hiding the label of input values using the underscore symbol. When calling such functions, the label of input values can be omitted. However, the label still needs to be set for the inner code.

dull>func hideLabeledFunc(_ a: Int, b: String) -> String {
dull>   print(a)
dull>   return b
dull>}

dull>hideLabeledFunc(1, "Hi")

To indicate when and what value will be returned in the inner code of a function, the "return" keyword is used. When a function is returned, the code below the "return" keyword will not be executed. Every function must end by returning something; otherwise, Dull Language will throw an error.

A special case for the return type is the "Void" type, which means the function will return nothing. In such cases, a return value is not required, and the function can simply end without returning a value.

dull>func voidReturn(_ a: Int) -> Void {
dull>   print(a)
dull>}

Calling functions in Dull Language is straightforward. The function name is used to call it, followed by input values with labels. The function will then return the output value.

dull>let helloText: String = hello(text: "Ryan")
dull>print(helloText)
dull>let hiText: String = hideLabeledFunc(1, "Hi")
dull>print(hiText)

"""#),
    Documentation(title: "Operators", index: 5, practice: false, fullText: #"""
The Dull programming language supports three types of operators: calculate operators, compare operators, and logical operators. These operators are prioritized in the following order: calculate operators have the highest priority, followed by compare operators, and finally logical operators.

There are three logical operators available in Dull: "and", "or", and "not", represented by the symbols "&&", "||", and "!", respectively. The "and" and "or" operators require two boolean values as input and return a boolean value. The "not" operator only requires a single boolean value as input and returns the opposite value.

dull>print(true && false)
dull>print(true || false)
dull>print(!true)

Dull also provides six compare operators: greater than (">"), greater than or equal to (">="), less than ("<"), less than or equal to ("<="), equal to ("=="), and not equal to ("!="). All compare operators require two values of the same type, which can be String, Int, or Double.

dull>print(1 > 2)
dull>print(3.0 >= 3.00)
dull>print("hello" == "hello")
dull>print("Hello" != "hello")

Calculate operators include "plus" ("+"), "minus" ("-"), "multiply" ("*"), and "divide" ("/"). These operators require two values of the same type, which can be Int or Double.

dull>print(23 / 12 + 2 - 1 * 4)
dull>print(23.0 / 12.0 + 2.0 - 1.0 * 4.0)

Operators with higher priority, such as "multiply" and "divide", are performed before operators with lower priority, such as "plus" and "minus".

Parentheses ("()") can be used to modify the order of operation, giving an expression higher priority.

dull>print(1 + (2 - 3) * 3)
dull>print(true || (false && true) && false)

When operators have the same priority, they are executed in order.

dull>print(true || false && true)

In summary, Dull's operator system includes calculate, compare, and logical operators, each with specific rules and requirements. By understanding these rules, programmers can write efficient and effective code in the Dull programming language.
"""#),
    Documentation(title: "Shortcut: Calculate Operator", index: 6, practice: false, fullText: #"""
Assuming that a variable named "a" has been defined with an Integer data type and an initial value of 0, it is desired to assign a new value to it which is one more than its current value. This can be achieved by adding 1 to the current value and then assigning the result to the variable.

dull>var a: Int = 0
dull>a = a + 1
dull>print(a)

However, there is a shorthand notation that can be used for such operations. Specifically, the "self-increase" operator (+=) can be used to add a specified value to the variable's current value and assign the result back to the variable. Similarly, the "self-decrease" (-=) operator and "self-multiply" (*=) operator can be used to subtract and multiply the current value of the variable, respectively, and then assign the result back to the variable.

dull>var b: Int = 0
dull>b += 3
dull>b -= a
dull>b *= 2
dull>print(b)

The shorthand notations can help to write concise and readable code, especially when performing repetitive arithmetic operations on a variable.
"""#),
    Documentation(title: "Practice #2", index: 7, practice: true,practices: [
        .init(code: #"""
let value1: Int = 1.0
value1 += 3
let value2 = 3
value2 -= 1
"""#, evaluation: { aboveCode, code in
    do {
        let scope = try DullLanguage.shared.preRun(code: aboveCode)
        try DullLanguage.shared.runWithScope(code: code, config: [], scope: scope)
        return scope.haveVaribale(name: "value1", type: "Int") && scope.haveVaribale(name: "value2", type: "Int") && scope.testValue(name: "value1", value: DullInt(value: 4)) && scope.testValue(name: "value2", value: DullInt(value: 2))
    } catch {
        return false
    }
        }),
        .init(code: "", evaluation: { aboveCode, code in
            let scope = try DullLanguage.shared.preRun(code: aboveCode)
            try DullLanguage.shared.runWithScope(code: code, config: [], scope: scope)
            if let function = scope.getRawFunction(name: "scale") {
                if function.pass.count == 2 {
                    try DullLanguage.shared.runWithScope(code: "var a: Int = scale(value1: 21, value2: 18)", config: [], scope: scope)
                    return scope.haveVaribale(name: "a", type: "Int") && scope.testValue(name: "a", value: DullInt(value: 117))
                } else {
                    return false
                }
            } else {
                return false
            }
        }),
        .init(code: "", evaluation: { aboveCode, code in
            var result = ""
            let config = [OutputConfig({ str in
                result += str
            })]
            let scope = try DullLanguage.shared.preRun(code: aboveCode)
            try DullLanguage.shared.runWithScope(code: code, config: config, scope: scope)
            return "12" + "\n" == result
        })
    ], fullText: #"""
This is a practice exercise that requires adherence to the provided guidelines in order to complete it.

Firstly, you need to locate and correct the code error below.

practice>0

Secondly, a function called "scale" must be composed, which will have two inputs labelled "value1" and "value2", both of which are Integers. The output of this function should be the result of multiplying the sum of the two inputs by their difference.

practice>1

Thirdly, the function "scale" must be called, with the input variables being those identified in the first step. Print the result of the "scale" function.

practice>2
"""#),
    Documentation(title: "Loop", index: 8, practice: false, fullText: #"""
The while loop in Dull is a type of control flow statement that allows a section of code to be executed repeatedly based on a specified condition. The while loop consists of two parts: the loop condition and the loop body.

dull>while false { print("hi") }

The loop condition is a boolean expression that determines whether the loop body should be executed. The loop body is the code that will be executed repeatedly as long as the loop condition remains true.

The condition must be a boolean expression that evaluates to either true or false. If the condition is true, the loop body will be executed. After the loop body has been executed, the condition will be checked again. If the condition is still true, the loop body will be executed again. This process will continue until the condition is false.

dull>var i: Int = 0
dull>while i < 5 {
dull>   print(i)
dull>   i += 1
dull>}

It is important to ensure that the loop condition will eventually become false, otherwise the loop will continue to execute indefinitely, resulting in an infinite loop.
"""#),
    Documentation(title: "Conditional Control Statement", index: 9, practice: false, fullText: #"""
In the Dull, the "if" keyword allows for the execution of a code block only when a given condition is true. In addition, the "else" keyword can be used to specify an alternative code block that will be executed if the condition is false.

dull>var condition1: Bool = true
dull>let condition2: Bool = false
dull>
dull>if condition1 || condition2 {
dull>   print("Hello Ryan")
dull>}
dull>
dull>if condition1 && condition2 {
dull>   print("Hello Dull")
dull>} else {
dull>   print("Hummmm...")
dull>}

The "if else" construct in the Dull allows for the specification of multiple conditions and their corresponding code blocks. These conditions are evaluated in sequence, with the first true condition resulting in the execution of its corresponding code block. If none of the conditions are true, the code block specified by the "else" keyword is executed.

dull>condition1 = false
dull>if condition1 || condition2 {
dull>   print("Hello Ryan")
dull>} else if !condition1 {
dull>   print("Hello, Dull")
dull>} else {
dull>   print("Hummmm...")
dull>}

Another related construct in programming is the "guard condition" statement. This statement is used to protect a code block from execution unless a specified condition is true. If the condition is true, nothing happens and the code block below the guard statement is executed as usual. If the condition is false, the code block specified by the "else" keyword is executed instead. Note that guard conditions only support a single condition.

dull>func dull(_ text: String) -> String {
dull>   guard text != "" else { return "Input Text" }
dull>   return "Dull: " + text
dull>}
dull>print(dull("I am a programming language"))
"""#),
    Documentation(title: "Build-in Functions", index: 10, practice: false, fullText: #"""
Before taking the final test, it is worth noting that there are three built-in functions that may be useful. The first is the ubiquitous "print" function, which you may have used extensively already.

The second is "convertToString", which takes one input (hiden label) that can be of any type. This function converts the input value to a string representation.

dull>print(convertToString("hi"))
dull>print(convertToString(-1))
dull>print(convertToString(2.7))
dull>print(convertToString(true))
dull>print(convertToString(()))

The third function is "randomInt", which takes two inputs labelled "start" and "end", both of which must be of the Int type. This function returns a random integer value between the "start" and "end" values, inclusively of "start" but exclusive of "end".

dull>print(randomInt(start: 1, end: 11))

We hope that these built-in functions will be helpful in completing the test successfully.
"""#),
    Documentation(title: "Final Test", index:11 , practice: true, practices: [
        .init(code: "", evaluation: { aboveCode, code in
            let scope = try DullLanguage.shared.preRun(code: aboveCode)
            try DullLanguage.shared.runWithScope(code: code, config: [], scope: scope)
            if let function = scope.getRawFunction(name: "addSmile") {
                if function.pass.count == 1 {
                    try DullLanguage.shared.runWithScope(code: "var a: String = addSmile(false)", config: [], scope: scope)
                    let test1 = scope.haveVaribale(name: "a", type: "String") && scope.testValue(name: "a", value: DullString(value: "false :)"))
                    try DullLanguage.shared.runWithScope(code: "var b: String = addSmile(-1.37)", config: [], scope: scope)
                    let test2 = scope.haveVaribale(name: "b", type: "String") && scope.testValue(name: "b", value: DullString(value: "-1.37 :)"))
                    try DullLanguage.shared.runWithScope(code: "var c: String = addSmile(()))", config: [], scope: scope)
                    let test3 = scope.haveVaribale(name: "c", type: "String") && scope.testValue(name: "c", value: DullString(value: "() :)"))
                    try DullLanguage.shared.runWithScope(code: #"var d: String = addSmile("")"#, config: [], scope: scope)
                    let test4 = scope.haveVaribale(name: "d", type: "String") && scope.testValue(name: "d", value: DullString(value: "hmmm..."))

                    print(test1, test2, test3, test4)

                    return test1 && test2 && test3 && test4
                } else {
                    return false
                }
            } else {
                return false
            }
        }),
        .init(code: "", evaluation: { aboveCode, code in
            func run() throws -> (DullScope, String) {
                var result = ""
                let config = [OutputConfig({ str in
                    result += str
                })]
                let scope = try DullLanguage.shared.preRun(code: aboveCode)
                try DullLanguage.shared.runWithScope(code: code, config: config, scope: scope)
                return (scope, result)
            }

            func gainReuslt(_ int: Int) -> String {
                var res = ""
                var i = 1

                while i <= int {
                    if i == 3 || i == 6 {} else {
                        res += "\(i) :)" + "\n"
                    }

                    i += 1
                }

                return res
            }

            var total = 0
            var sum = 0

            for _ in 0..<5 {
                let (scope, result) = try run()

                if scope.haveVaribale(name: "peopleCount", type: "Int"), let value = try? scope.getVariableValue(name: "peopleCount"), let int = value as? DullInt {
                    if total == 0 {
                        total = 5 * int.value
                    }
                    sum += int.value
                    if gainReuslt(int.value).trimmingCharacters(in: .whitespacesAndNewlines) != result.trimmingCharacters(in: .whitespacesAndNewlines) {
                        return false
                    }
                } else {
                    return false
                }
            }

            return sum != total
        }),
    ], fullText: #"""
This is the final test that determines your proficiency in the Dull language. To pass this test, you need to strictly adhere to the given guidelines.

Question 1: Create a function named "addSmile" that takes one input, labeled "item." The function should return a string that concatenates the input value with a smiley face. For example, if the input is 1 (Int), the function should return "1 :)", and if the input is true (Bool), it should return "true :)" . If an empty string is passed as input, the function should return "hmmm...".

Hint: built-in functions, condition statements, and Any Type

practice>0

Question 2: Define a variable named "peopleCount" with a type of Int. The "peopleCount" variable should not have a fixed value. Every time the code is run, this variable should be different and greater than 3. We will use the "addSmile" function to show my smile to them and print the text respectively. Each person will be given a label starting from 1. There is a special rule that if a person's label is 3 or 6, I won't show a smile.

For example, if the people count is 9, the output should be:
1 :)
2 :)
4 :)
5 :)
7 :)
8 :)
9 :)

Hint: built-in functions, condition statements, loop

practice>1
"""#),
]
