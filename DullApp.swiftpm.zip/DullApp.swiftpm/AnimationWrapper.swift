//
//  AnimationWrapper.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import SwiftUI

struct AnimatedViewWrapper<Content: View>: View {
    @State private var isAnimating1 = false
    @State private var isAnimating2 = true
    let duration1: Double
    let duration2: Double
    let content: () -> Content

    var body: some View {
        content()
            .opacity((isAnimating1 && isAnimating2) ? 1.0 : 0.0)
            .animation(.easeInOut(duration: duration1), value: isAnimating1)
            .animation(.easeInOut(duration: duration2), value: isAnimating2)
            .onAppear {
                self.isAnimating1 = true
            }
            .onDisappear {
                self.isAnimating2 = false
            }
    }
}
