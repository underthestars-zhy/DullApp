//
//  Documentations.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import Foundation

struct Documentation {
    let title: String
    let index: Int
    let practice: Bool
    let practices: [Practice]

    var headline: String {
        "\(index). \(title)"
    }

    let fullText: String

    init(title: String, index: Int, practice: Bool, practices: [Practice] = [], fullText: String) {
        self.title = title
        self.index = index
        self.practice = practice
        self.practices = practices
        self.fullText = fullText
    }
}

struct Practice {
    let code: Holder
    let evaluation: (String, String) throws -> Bool

    init(code: String, evaluation: @escaping (String, String) throws -> Bool) {
        self.code = Holder(value: code)
        self.evaluation = evaluation
    }
}
