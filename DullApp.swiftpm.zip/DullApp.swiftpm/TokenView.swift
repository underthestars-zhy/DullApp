//
//  TokenView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct TokenView: View {
    let level: Int
    let token: DullToken

    var body: some View {
        LazyVStack(spacing: 0) {
            switch token {
            case .letKeyword:
                DefaultTokenView(text: "Keyword: let")
            case .varKeyword:
                DefaultTokenView(text: "Keyword: var")
            case .swiftKeyword:
                DefaultTokenView(text: "Keyword: swift")
            case .identifier(let string):
                DefaultTokenView(text: "Identifier: \(string)")
            case .colon:
                DefaultTokenView(text: "Colon: :")
            case .type(let dullTypeHolder):
                DefaultTokenView(text: "Type: \(dullTypeHolder.type.typeIdentifier)")
            case .equal:
                DefaultTokenView(text: "Equal: =")
            case .value(let dullValueHolder):
                DefaultTokenView(text: "Value: \(dullValueHolder.value.type.typeIdentifier)(\(dullValueHolder.value.valueString))")
            case .line(let array):
                SubTokenView(name: "Line", tokens: array, level: level)
            case .root(let array):
                VStack(spacing: 30) {
                    ForEach(array.map({ t in
                        DullTokenWrapper(token: t)
                    })) { token in
                        TokenView(level: level + 1, token: token.token)
                    }
                }
            case .fnKeyword:
                DefaultTokenView(text: "Keyword: func")
            case .leftParenthesis:
                DefaultTokenView(text: "Left Parenthesis: (")
            case .rightParenthesis:
                DefaultTokenView(text: "Right Parenthesis: )")
            case .comma:
                DefaultTokenView(text: "Comma: ,")
            case .arrow:
                DefaultTokenView(text: "Arror: ->")
            case .returnType(let string):
                DefaultTokenView(text: "Return Type: \(string)")
            case .leftBrace:
                DefaultTokenView(text: "Left Brace: {")
            case .rightBrace:
                DefaultTokenView(text: "Right Brace: }")
            case .scope(let array):
                SubTokenView(name: "Scope", tokens: array, level: level)
            case .underscore:
                DefaultTokenView(text: "Underscore: _")
            case .returnKeyword:
                DefaultTokenView(text: "Keyword: return")
            case .plus:
                DefaultTokenView(text: "Plus: +")
            case .minus:
                DefaultTokenView(text: "Minus: -")
            case .multiply:
                DefaultTokenView(text: "Multiply: *")
            case .divide:
                DefaultTokenView(text: "Divide: /")
            case .greaterThan:
                DefaultTokenView(text: "Greater Than: >")
            case .lessThan:
                DefaultTokenView(text: "Less Than: <")
            case .greaterThanOrEqual:
                DefaultTokenView(text: "Greater Than or Equal: >=")
            case .lessThanOrEqual:
                DefaultTokenView(text: "Less Than or Equal: <=")
            case .equalTo:
                DefaultTokenView(text: "Equal to: ==")
            case .notEqualTo:
                DefaultTokenView(text: "Not Equal to: !=")
            case .ifKeyword:
                DefaultTokenView(text: "Keyword: if")
            case .elseKeyword:
                DefaultTokenView(text: "Keyword: else")
            case .whileKeyword:
                DefaultTokenView(text: "Keyword: while")
            case .plusEqual:
                DefaultTokenView(text: "Plau Equal: +=")
            case .minusEqual:
                DefaultTokenView(text: "Minus Equal: -=")
            case .multiplyEqual:
                DefaultTokenView(text: "Multiply Equal: *=")
            case .and:
                DefaultTokenView(text: "And: &&")
            case .or:
                DefaultTokenView(text: "Or: ||")
            case .not:
                DefaultTokenView(text: "Not: !")
            case .guardKeyword:
                DefaultTokenView(text: "Keyword: guard")
            }
        }
        .frame(width: 1000 - (60*Double(level)))
        .frame(minHeight: 60)
        .overlay {
            if level >= 0 {
                RoundedRectangle(cornerRadius: 30)
                    .stroke(Color.black, lineWidth: 6)
            }
        }
    }
}

struct SubTokenView: View {
    let name: String
    let tokens: [DullToken]
    let level: Int

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text("\(name):")
                    .font(.system(size: 32, weight: .heavy, design: .monospaced))
                    .padding(.leading, 30)
                    .padding(.horizontal, 20)

                Spacer()
            }
            .padding(.top, 20)

            LazyVStack(spacing: 30) {
                ForEach(tokens.map({ t in
                    DullTokenWrapper(token: t)
                })) { token in
                    TokenView(level: level + 1, token: token.token)
                }
            }
            .padding(.top, 20)
            .padding(.bottom, 30)
        }
    }
}

struct DefaultTokenView: View {
    let text: String

    var body: some View {
        HStack(spacing: 0) {
            Text(text)
                .font(.system(size: 24, weight: .bold, design: .monospaced))
                .padding(.leading, 30)
                .padding(.vertical, 18)
            Spacer()
        }
        .frame(minHeight: 60)
    }
}

struct DullTokenWrapper: Identifiable {
    let id = UUID()

    let token: DullToken
}
