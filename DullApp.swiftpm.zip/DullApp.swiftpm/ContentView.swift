import SwiftUI

struct ContentView: View {
    @State var state: HomePageState = .none
    @State var runState: RunningState = .none
    @Namespace var animationSpace

    @StateObject var playgroundManager = PlaygroundManager.shared

    @State var setName = false
    @State var playgroundName = ""
    @State var code = ""
    @State var output = ""

    @State var errorQuene = [ErrorWrapper]()

    @State var scannerToken: DullToken = .root([])
    @State var parserGrammar: DullGrammarType = .root([])

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 0) {
                ZStack {
                    Image("Banner")
                        .resizable()
                        .scaledToFit()
                        .frame(width: calImageWidth())
                        .padding(.top, 30)

                    if case .playgroundEdit(let playgroundMeta) = state {
                        AnimatedViewWrapper(duration1: 2, duration2: 0.5) {
                            HStack {
                                BackButton(dark: true) {
                                    func directBack() {
                                        if playgroundMeta.name.isEmpty {
                                            setName = true
                                        }


                                        if !playgroundName.isEmpty || !playgroundMeta.name.isEmpty {
                                            do {
                                                if playgroundMeta.name.isEmpty && !playgroundName.isEmpty {
                                                    try playgroundManager.createNewPlayground(name: playgroundName, code: code)
                                                } else {
                                                    try playgroundManager.updatePlayground(meta: playgroundMeta, code: code)
                                                }
                                            } catch {
                                                print(error)
                                            }

                                            state = .playground
                                            code = ""
                                        }
                                    }

                                    switch runState {
                                    case .none:
                                        directBack()
                                    case .direct:
                                        directBack()
                                    case .scanner:
                                        runState = .none
                                    case .parser:
                                        runState = .scanner
                                    case .result:
                                        runState = .parser
                                    }
                                }
                                .alert("Set Playground Name", isPresented: $setName) {
                                    TextField("", text: $playgroundName)
                                }
                                .onChange(of: setName) { newValue in
                                    if !newValue {
                                        if !playgroundName.isEmpty {
                                            do {
                                                try playgroundManager.createNewPlayground(name: playgroundName, code: code)
                                                state = .playground
                                            } catch {
                                                print(error)
                                            }

                                            code = ""
                                        }
                                    }
                                }

                                Spacer()

                                switch runState {
                                case .none:
                                    RunButton {
                                        if testRun() {
                                            stepRunScanner()
                                        }
                                    } direct: {
                                        directRun()
                                    }
                                case .direct:
                                    CodeButton {
                                        output = ""
                                        runState = .none
                                    }
                                case .scanner:
                                    NextButton {
                                        stepRunParser()
                                    }
                                case .parser:
                                    NextButton {
                                        stepRunReuslt()
                                    }
                                case .result:
                                    CodeButton {
                                        output = ""
                                        runState = .none
                                    }
                                }
                            }
                            .padding(.horizontal, 50)
                            .padding(.top, 30)
                        }
                    }
                }


                if case .playgroundEditTransition(let playgroundMeta) = state {
                    AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                        Text("Loading...")
                            .font(.system(size: 36, weight: .heavy, design: .monospaced))
                            .task {
                                try? await Task.sleep(for: .seconds(2))
                                errorQuene = []
                                do {
                                    code = try playgroundManager.fetchContent(for: playgroundMeta)
                                    state = .playgroundEdit(playgroundMeta)
                                } catch {
                                    print(error.localizedDescription)
                                }
                            }
                    }
                }

                if showStep() {
                    switch runState {
                    case .none:
                        EmptyView()
                    case .direct:
                        EmptyView()
                    case .scanner:
                        Text("</ Scanner Result />")
                            .font(.system(size: 36, weight: .bold, design: .monospaced))
                    case .parser:
                        Text("</ Parser Result />")
                            .font(.system(size: 36, weight: .bold, design: .monospaced))
                    case .result:
                        Text("</ Running Result />")
                            .font(.system(size: 36, weight: .bold, design: .monospaced))
                    }
                }
            }

            ShowViewWrapper(show: !transition() && !showStep()) {
                VStack(spacing: 0) {
                    switch state {
                    case .none:
                        AnimatedViewWrapper(duration1: 0.5, duration2: 0.5) {
                            VStack(spacing: 50) {
                                HomePageItem(imageName: "sparkles", text: "About Dull") {
                                    state = .about
                                }

                                HomePageItem(imageName: "doc.append.fill", text: "Learning") {
                                    state = .doc
                                }

                                HomePageItem(imageName: "paperplane.fill", text: "Playground") {
                                    state = .playground
                                }
                            }
                            .padding(.top, 60)
                        }

                        Spacer()

                        AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                            Text("Made By Ryan Zhu")
                                .multilineTextAlignment(.center)
                                .padding(.bottom, 30)
                                .font(.system(size: 18, weight: .bold, design: .monospaced))
                                .foregroundColor(.white)
                        }
                    case .about:
                        VStack(spacing: 0) {
                            AnimatedViewWrapper(duration1: 1, duration2: 0.7) {
                                HomePageTopBar(imageName: "sparkles", text: "About Dull") {
                                    state = .none
                                }
                                .padding(.top, 40)
                            }

                            AnimatedViewWrapper(duration1: 1, duration2: 0.7) {
                                ScrollView(showsIndicators: false) {
                                    Text(aboutText)
                                        .font(.system(size: 21, weight: .semibold, design: .monospaced))
                                        .lineSpacing(20)
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                        .padding(.horizontal, 50)
                                        .padding(.bottom, 30)
                                }
                            }


                            Spacer()
                        }
                    case .doc, .docFull:
                        VStack {
                            AnimatedViewWrapper(duration1: 1, duration2: 0.7) {
                                HomePageTopBar(imageName: "doc.append.fill", text: "Learning") {
                                    if currentDocFull() {
                                        state = .doc
                                    } else {
                                        state = .none
                                    }
                                }
                                .padding(.top, 40)
                            }

                            ScrollViewReader { reader in
                                ScrollView(showsIndicators: false) {
                                    VStack(spacing: 0) {
                                        VStack(spacing: 0) {}
                                            .frame(height: 0)
                                            .id("top")

                                        VStack(spacing: 40) {
                                            ForEach(documentations, id: \.index) {documentation in
                                                ShowViewWrapper(show: currentDocFull() ? (currentDoc(index: documentation.index) ? true : false) : true) {
                                                    DocItem(documentation: documentation, expanded: currentDoc(index: documentation.index), state: $state)
                                                }
                                            }

                                            if case .docFull(let int) = state {
                                                if documentations[int-1].practice {
                                                    AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                                                        DullPracticeView(doc: documentations[int-1])
                                                            .task {
                                                                try? await Task.sleep(for: .seconds(1))
                                                                withAnimation(.easeInOut) {
                                                                    reader.scrollTo("top", anchor: .top)
                                                                }
                                                            }
                                                            .onDisappear {
                                                                Task {
                                                                    try? await Task.sleep(for: .seconds(1))
                                                                    withAnimation(.easeInOut) {
                                                                        reader.scrollTo("top", anchor: .top)
                                                                    }
                                                                }
                                                            }
                                                    }
                                                } else {
                                                    AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                                                        DullTextView(text: documentations[int-1].fullText)
                                                            .task {
                                                                try? await Task.sleep(for: .seconds(1))
                                                                withAnimation(.easeInOut) {
                                                                    reader.scrollTo("top", anchor: .top)
                                                                }
                                                            }
                                                            .onDisappear {
                                                                Task {
                                                                    try? await Task.sleep(for: .seconds(1))
                                                                    withAnimation(.easeInOut) {
                                                                        reader.scrollTo("top", anchor: .top)
                                                                    }
                                                                }
                                                            }
                                                    }
                                                }

                                            }
                                        }
                                    }
                                    .padding(.top, 40)
                                    .padding(.bottom, 40)
                                }
                            }

                            Spacer()
                        }
                    case .playground:
                        VStack {
                            AnimatedViewWrapper(duration1: 1, duration2: 0.7) {
                                HomePageTopBar(imageName: "paperplane.fill", text: "Playground") {
                                    state = .none
                                }
                                .overlay {
                                    HStack {
                                        Spacer()

                                        Circle()
                                            .frame(width: 60, height: 60)
                                            .foregroundColor(.white)
                                            .overlay {
                                                Button {
                                                    setName = false
                                                    playgroundName = ""
                                                    code = ""
                                                    output = ""
                                                    state = .playgroundEditTransition(.init(name: "", lastEdit: Date()))
                                                } label: {
                                                    Image(systemName: "plus")
                                                        .foregroundColor(.black)
                                                        .font(.system(size: 36, weight: .semibold))
                                                }
                                            }
                                    }
                                }
                                .padding(.top, 40)
                            }

                            LazyVGrid(columns: [.init(.fixed(260), spacing: 60), .init(.fixed(260), spacing: 60), .init(.fixed(260))], spacing: 40) {
                                ForEach(generatePlaygroundWrapper()) { playWrapper in
                                    AnimatedViewWrapper(duration1: playWrapper.animationTime, duration2: 0.5) {
                                        PlaygroundItem(name: playWrapper.item.name, lastEditedTime: playWrapper.item.lastEdit) {
                                            state = .playgroundEditTransition(playWrapper.item)
                                        }
                                    }
                                }
                            }
                            .padding(.top, 40)

                            Spacer()
                        }
                    case .playgroundEdit(let meta):
                        VStack(spacing: 0) {
                            ForEach(errorQuene) { error in
                                ErrorBanner(error: error.error, width: 900)
                                    .padding(.top, 40)
                            }

                            AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                                DullEditor(runState: $runState, code: $code, output: output, playgroundMeta: meta)
                                    .padding(.horizontal, 50)
                                    .padding(.vertical, 40)
                                    .onChange(of: runState) { state in
                                        if state == .direct {
                                            errorQuene = []
                                        }
                                    }
                            }

                            Spacer()
                        }
                        .background(.clear)
                    default:
                        EmptyView()
                    }
                }
                .frame(width: calFrameeWidth())
                .background(isEdite() ? .clear : .black)
                .clipShape(TopRoundedRectangle(cornerRadius: 60))
                .padding(10)
                .overlay {
                    if isEdite() {
                        TopRoundedRectangle(cornerRadius: 60)
                            .stroke(Color.black, lineWidth: 10)
                    }
                }
                .padding(-10)
                .padding(.top, 30)
            }

            ShowViewWrapper(show: showStep()) {
                switch runState {
                case .none:
                    EmptyView()
                case .direct:
                    EmptyView()
                case .scanner:
                    VStack {
                        AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                            ScrollView(showsIndicators: false) {
                                TokenView(level: -1, token: scannerToken)
                                    .padding(.top, 30)

                                Spacer()
                            }
                        }
                    }
                case .parser:
                    VStack {
                        AnimatedViewWrapper(duration1: 1, duration2: 0.5) {
                            ScrollView(showsIndicators: false) {
                                GrammarView(level: -1, grammar: parserGrammar)
                                    .padding(.top, 30)

                                Spacer()
                            }
                        }
                    }
                case .result:
                    VStack {
                        HStack {
                            Text(output)
                                .font(.system(size: 24, weight: .bold, design: .monospaced))
                                .padding(.horizontal, 50)
                                .padding(.vertical, 40)

                            Spacer()
                        }

                        Spacer()
                    }
                    .frame(width: 1000)
                    .clipShape(TopRoundedRectangle(cornerRadius: 60))
                    .padding(10)
                    .overlay {
                        if isEdite() {
                            TopRoundedRectangle(cornerRadius: 60)
                                .stroke(Color.black, lineWidth: 10)
                        }
                    }
                    .padding(-10)
                    .padding(.top, 30)
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
        .animation(.easeInOut(duration: 1), value: state)
        .animation(.easeInOut(duration: 1), value: runState)
    }

    func calImageWidth() -> Double {
        switch state {
        case .none:
            return 600
        case .about:
            return 300
        case .doc:
            return 300
        case .docFull:
            return 0
        case .playground:
            return 300
        case .playgroundEditTransition:
            return 800
        case .playgroundEdit:
            return 300
        }
    }

    func calFrameeWidth() -> Double {
        switch state {
        case .none:
            return 900
        case .about:
            return 1000
        case .doc:
            return 1000
        case .docFull:
            return 1000
        case .playground:
            return 1000
        case .playgroundEditTransition:
            return 1000
        case .playgroundEdit:
            return 1000
        }
    }

    func currentDoc(index: Int) -> Bool {
        if case .docFull(let int) = state {
            return index == int
        }

        return false
    }

    func currentDocFull() -> Bool {
        if case .docFull = state {
            return true
        }

        return false
    }

    struct PlaygroundWrapper: Identifiable {
        let id: Int
        var animationTime: Double {
            1 + 0.5 * Double(id)
        }
        let item: PlaygroundMeta
    }

    func generatePlaygroundWrapper() -> [PlaygroundWrapper] {
        self.playgroundManager.playgrounds.reversed().enumerated().map { metaW in
            PlaygroundWrapper(id: metaW.offset, item: metaW.element)
        }
    }

    func transition() -> Bool {
        if case .playgroundEditTransition = state {
            return true
        }

        return false
    }

    func isEdite() -> Bool {
        if case .playgroundEdit = state {
            return true
        }

        return false
    }

    func directRun() {
        output = ""
        let config = [OutputConfig({ str in
            output += str
        })]
        do {
            try DullLanguage.shared.run(code: code, config: config)
        } catch {
            withAnimation(.easeInOut(duration: 0.5)) {
                errorQuene.append(.init(error: error))
            }
            return
        }

        runState = .direct
    }

    func testRun() -> Bool {
        do {
            try DullLanguage.shared.run(code: code, config: [])
        } catch {
            withAnimation(.easeInOut(duration: 0.5)) {
                errorQuene.append(.init(error: error))
            }
            return false
        }

        return true
    }

    func stepRunScanner() {
        do {
            let token = try DullScaner(input: code).scan()
            scannerToken = token
            runState = .scanner
        } catch {
            return
        }
    }

    func stepRunParser() {
        let grammar = DullParser(token: scannerToken).parse()
        parserGrammar = grammar
        runState = .parser
    }

    func stepRunReuslt() {
        output = ""
        let config = [OutputConfig({ str in
            output += str
        })]
        do {
            try DullProcessor(grammar: parserGrammar, config: config).process()
        } catch {
            return
        }

        runState = .result
    }

    func showStep() -> Bool {
        switch runState {
        case .none:
            return false
        case .direct:
            return false
        case .scanner:
            return true
        case .parser:
            return true
        case .result:
            return true
        }
    }
}

struct ErrorWrapper: Identifiable {
    let id = UUID()
    let error: Error
}

enum HomePageState: Equatable {
    case none
    case about
    case doc
    case docFull(Int)
    case playground
    case playgroundEditTransition(PlaygroundMeta)
    case playgroundEdit(PlaygroundMeta)
}

enum RunningState {
    case none
    case direct
    case scanner
    case parser
    case result
}

struct DocItem: View {
    let documentation: Documentation
    let expanded: Bool

    @Binding var state: HomePageState

    @ObservedObject var practiceManager = PracticeManager.shared

    var body: some View {
        AnimatedViewWrapper(duration1: calDocItemAnimation(documentation.index), duration2: 0.5) {
            DocumentationItem(expanded: expanded, finished: documentation.practice ? practiceManager.finished[documentation.index] ?? false : false, text: documentation.headline) {
                state = .docFull(documentation.index)
            }
        }
    }

    func calDocItemAnimation(_ index: Int) -> Double {
        1 + 0.5 * Double((index-1))
    }
}

struct HomePageItem: View {
    let imageName: String
    let text: String

    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                Image(systemName: imageName)
                    .font(.system(size: 54))
                    .foregroundColor(.black)
                    .padding(.leading, 30)

                Text(text)
                    .font(.system(size: 36, weight: .bold, design: .monospaced))
                    .padding(.leading, 30)

                Spacer()

                Circle()
                    .foregroundColor(.black)
                    .frame(width: 60, height: 60)
                    .overlay {
                        Image(systemName: "arrow.right")
                            .foregroundColor(.white)
                            .font(.system(size: 24))
                    }
                    .padding(.trailing, 30)
            }
            .frame(width: 800, height: 100)
            .background(.white)
            .cornerRadius(25)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
