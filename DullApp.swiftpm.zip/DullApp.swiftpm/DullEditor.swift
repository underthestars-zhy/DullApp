//
//  DullEditor.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct DullEditor: View {
    @FocusState var focus: Bool
    @Binding var runState: RunningState
    @Binding var code: String
    let output: String

    let playgroundMeta: PlaygroundMeta

    @StateObject var playgroundManager = PlaygroundManager.shared
    
    var body: some View {
        VStack {
            if runState == .none {
                TextEditor(text: $code)
                    .autocorrectionDisabled()
                    .autocapitalization(.none)
                    .keyboardType(.alphabet)
                    .font(.system(size: 24, weight: .bold, design: .monospaced))
                    .focused($focus)
                    .onAppear {
                        focus = true
                    }
                    .scrollContentBackground(.hidden)
            } else if runState == .direct {
                HStack {
                    Text(output)
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .background(.clear)

                    Spacer()
                }
            }
        }
    }
}
