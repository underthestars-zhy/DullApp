//
//  PracticeManager.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/18.
//

import Foundation

class PracticeManager: ObservableObject {
    static let shared = PracticeManager()

    @Published var finished: [Int : Bool] = [:]

    func updateFinishedStatus() {
        var practiceIndex = [Int]()

        for doc in documentations {
            if doc.practice {
                practiceIndex.append(doc.index)
            }
        }

        for index in practiceIndex {
            finished[index] = UserDefaults.standard.bool(forKey: "pratice_\(index)")
        }
    }

    func finish(index: Int) {
        UserDefaults.standard.set(true, forKey: "pratice_\(index)")
        finished[index] = true
    }

    init() {
        updateFinishedStatus()
    }
}
