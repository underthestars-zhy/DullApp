//
//  RunButton.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct RunButton: View {
    let step: () -> ()
    let direct: () -> ()

    var body: some View {
        Menu {
            Button("Step Run") {
                step()
            }

            Button("Direct Run") {
                direct()
            }
        } label: {
            HStack(spacing: 0) {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 24, weight: .regular))
                    .padding(.leading, 25)
                    .foregroundColor(.white)
                    .padding(.trailing, 16)

                Text("RUN")
                    .font(.system(size: 24, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(.trailing, 25)
            }
            .frame(height: 60)
            .background(.black)
            .cornerRadius(30)
        }

    }
}
