//
//  PlaygroundManager.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import Foundation

class PlaygroundManager: ObservableObject {
    static let shared = PlaygroundManager()

    let url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)

    var metaJSON: URL {
        url.appending(path: "meta.json")
    }

    @Published var playgrounds = [PlaygroundMeta]()

    init() {
        print(url)
        if !FileManager.default.fileExists(atPath: metaJSON.path()) {
            createMetaJSON()
        }

        playgrounds = (try? fetchMetaData()) ?? []
    }

    func createMetaJSON() {
        FileManager.default.createFile(atPath: metaJSON.path(), contents: try? JSONEncoder().encode([PlaygroundMeta]()))
        try? FileManager.default.createDirectory(at: url.appending(path: "playgrounds"), withIntermediateDirectories: true)
    }

    func fetchContent(for meta: PlaygroundMeta) throws -> String {
        if FileManager.default.fileExists(atPath: meta.filePath.path()) {
            return try String(contentsOf: meta.filePath)
        }

        return ""
    }

    func fetchMetaData() throws -> [PlaygroundMeta] {
        let data = try Data(contentsOf: metaJSON)
        return try JSONDecoder().decode([PlaygroundMeta].self, from: data)
    }

    func saveMetaData(_ metaData: [PlaygroundMeta]) throws {
        let data = try JSONEncoder().encode(metaData)

        try data.write(to: metaJSON)
    }

    func createNewPlayground(name: String, code: String) throws {
        let meta = PlaygroundMeta(name: name, lastEdit: Date())

        FileManager.default.createFile(atPath: meta.filePath.path(), contents: code.data(using: .utf8))

        var metaData = try fetchMetaData()

        metaData.append(meta)
        playgrounds.append(meta)

        try saveMetaData(metaData)
    }

    func updatePlayground(meta: PlaygroundMeta, code: String) throws {
        try code.data(using: .utf8)?.write(to: meta.filePath)

        var metaData = try fetchMetaData()

        guard let index = metaData.firstIndex(where: {
            $0.uuid == meta.uuid
        }) else { return }

        metaData[index].lastEdit = Date()

        try saveMetaData(metaData)

        guard let pIndex = playgrounds.firstIndex(where: {
            $0.uuid == meta.uuid
        }) else { return }

        playgrounds[pIndex].lastEdit = Date()
    }
}

struct PlaygroundMeta: Codable, Equatable {
    let name: String
    var lastEdit: Date
    let uuid: UUID
    var filePath: URL {
        return PlaygroundManager.shared.url.appending(path: "playgrounds").appending(path: "\(uuid.uuidString).dull")
    }

    init(name: String, lastEdit: Date) {
        self.name = name
        self.lastEdit = lastEdit
        self.uuid = UUID()
    }

    init(name: String, lastEdit: Date, uuid: UUID) {
        self.name = name
        self.lastEdit = lastEdit
        self.uuid = uuid
    }
}
