//
//  DullPracticeCodeView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/18.
//

import SwiftUI

struct DullPracticeCodeView: View {
    let docIndex: Int
    let pratices: [Practice]
    let index: Int
    
    @State var focus: Bool = false

    @State var errorQuene = [ErrorWrapper]()

    @State var code = ""

    @State var check = false

    @Binding var totalResult: Int

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 0) {
                ForEach(errorQuene) { error in
                    ErrorBanner(error: error.error, width: 850)
                        .padding(.top, 30)
                }

                OmenTextField("", text: $code, isFocused: $focus, returnKeyType: .continue)
                    .lineLimit(1...)
                    .foregroundColor(.black)
                    .padding(.top, 20)
                    .padding(.horizontal, 30)
                    .frame(maxHeight: .infinity)
                    .onAppear {
                        code = pratices[index].code.value
                    }
                    .onChange(of: code) { newValue in
                        pratices[index].code.value = newValue
                    }

                HStack {
                    PracticeCheckButton(check: $check) {
                        let practice = pratices[index]
                        let aboveCode = getAboveCode()
                        do {
                            let temp = try practice.evaluation(aboveCode, code)
                            if temp && !check {
                                totalResult += 1
                            }
                            check = temp
                        } catch {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                errorQuene.append(.init(error: error))
                            }

                            check = false
                        }
                    }

                    Spacer()
                }
                .padding(.bottom, 20)
                .padding(.top, 20)
                .padding(.horizontal, 30)
            }
            .frame(width: 900)
            .background(.white)
            .cornerRadius(20)
        }
    }

    func getAboveCode() -> String {
        if index < 1 {
            return ""
        } else {
            return insertTextBetweenArrayElements(text: "\n", array: pratices.map(\.code)[0...(index-1)].map { $0.value }).reduce("", +)
        }
    }

    func insertTextBetweenArrayElements(text: String, array: [String]) -> [String] {
        var resultArray = [String]()

        for (index, element) in array.enumerated() {
            resultArray.append(element)

            if index != array.count - 1 {
                resultArray.append(text)
            }
        }

        return resultArray
    }
}
