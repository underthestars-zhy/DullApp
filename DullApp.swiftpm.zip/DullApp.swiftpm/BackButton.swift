//
//  BackButton.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import SwiftUI

struct BackButton: View {
    let dark: Bool
    let action: () -> ()

    var body: some View {
        Button {
            action()
        } label: {
            HStack(spacing: 0) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 36, weight: .semibold))
                    .padding(.leading, 20)
                    .foregroundColor(dark ? .white : .black)
                    .padding(.trailing, 7)

                Text("BACK")
                    .font(.system(size: 24, weight: .semibold, design: .monospaced))
                    .foregroundColor(dark ? .white : .black)
                    .padding(.trailing, 25)
            }
            .frame(height: 60)
            .background(dark ? .black : .white)
            .cornerRadius(30)
        }
    }
}

struct BackButton_Previews: PreviewProvider {
    static var previews: some View {
        BackButton(dark: true) {}
    }
}
