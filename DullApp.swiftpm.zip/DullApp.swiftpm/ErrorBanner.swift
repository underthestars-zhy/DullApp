//
//  ErrorBanner.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct ErrorBanner: View {
    let error: Error
    let width: Double

    @State var show = true

    var body: some View {
        if show {
            HStack(spacing: 20) {
                Image(systemName: "exclamationmark.circle.fill")
                    .font(.system(size: 36))
                    .foregroundColor(.white)
                    .padding(.leading, 30)

                Text(toText())
                    .font(.system(size: 24, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                    .padding(.leading, 20)

                Spacer()
            }
            .frame(width: width, height: 80)
            .background(.black)
            .cornerRadius(20)
            .task {
                try? await Task.sleep(for: .seconds(8))
                withAnimation(.easeInOut(duration: 0.5)) {
                    show = false
                }
            }
        }
    }

    func toText() -> String {
        if let scannerError = error as? ScanerError {
            switch scannerError {
            case .unexpectedChar(let character):
                return "Scanner Error: Unexpected Char (\(encodeEscapedCharacters("\(character)"))"
            case .unexpectedValue:
                return "Scanner Error: Unexpected Value"
            case .unclosedStringLiteral:
                return "Scanner Error: Unclosed String Literal"
            case .multipleDotsFound:
                return "Scanner Error: Multiple Dots Found"
            }
        } else if let processorError = error as? ProcessError {
            switch processorError {
            case .cannotFindMainProgram:
                return "Processor Error: Cannot Find Main Program"
            case .unexpectedRoot:
                return "Processor Error: Unexpected Root"
            case .unexpectedValue:
                return "Processor Error: Unexpected Value"
            case .duplicatedVariableName:
                return "Processor Error: Duplicated Varibale Name Found"
            case .duplicatedFunctionName:
                return "Processor Error: Duplicated Function Name Found"
            case .undefinedVariable:
                return "Processor Error: Undefined Variable Found"
            case .unmatchValueType:
                return "Processor Error: Unmatched Value Type Found"
            case .unexpectedFunctionName:
                return "Processor Error: Unexpected Function Name Found"
            case .unexpectedFunctionReturnType:
                return "Processor Error: Unexpected Function Return Type Found"
            case .unassignedValue:
                return "Processor Error: Unassigned Value Found"
            case .functionPassTypeUnmatch:
                return "Processor Error: Unmatched Function Pass Type Found"
            case .functionNoReturnValue:
                return "Processor Error: The Function Should Have a Return Value"
            case .dividedNumberCannotBeZero:
                return "Processor Error: Divieded Number Cannot Be Zero"
            case .unxpectedScope:
                return "Processor Error: Unexpected Scope Found"
            case .setConstantMultipleTimes:
                return "Processor Error: Set Constant Multiple Times"
            case .passValueCountNotMatch:
                return "Processor Error: Function Pass Value Count Not Match With the Requirement"
            }
        } else {
            return error.localizedDescription
        }
    }

    func encodeEscapedCharacters(_ input: String) -> String {
        var encoded = ""

        for char in input {
            switch char {
            case "\n":
                encoded.append("\\n")
            case "\t":
                encoded.append("\\t")
            case "\\":
                encoded.append("\\\\")
            case "\"":
                encoded.append("\\\"")
            default:
                encoded.append(char)
            }
        }

        return encoded
    }
}
