//
//  ShowViewWrapper.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/15.
//

import SwiftUI

struct ShowViewWrapper<Content>: View where Content: View {
    let show: Bool
    let view: Content

    init(show: Bool, @ViewBuilder view: () -> Content) {
        self.show = show
        self.view = view()
    }

    var body: some View {
        if show {
            view
        } else {
            EmptyView()
        }
    }
}
