//
//  DullPracticeView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/18.
//

import SwiftUI

struct DullPracticeView: View {
    let doc: Documentation

    @State var pItems = [DullPItem]()

    @State var totalResult = 0

    var body: some View {
        VStack(spacing: 30) {
            ForEach(pItems) { item in
                switch item {
                case .text(let text):
                    HStack {
                        Text(String(text[text.startIndex..<text.index(before: text.endIndex)]))
                            .font(.system(size: 21, weight: .semibold, design: .monospaced))
                            .lineSpacing(20)
                            .dismissKeyboardOnTap()
                            .foregroundColor(.white)
                            .padding(.horizontal, 50)

                        Spacer()
                    }
                case .code(let index):
                    DullPracticeCodeView(docIndex: doc.index, pratices: doc.practices, index: index, totalResult: $totalResult)
                }
            }
        }
        .padding(.bottom, 30)
        .onAppear {
            generateCTItems()
        }
        .onDisappear {
            if totalResult >= doc.practices.count {
                PracticeManager.shared.finish(index: doc.index)
            }
        }
    }

    func generateCTItems() {
        let splitedTexts = doc.fullText.split(omittingEmptySubsequences: false, whereSeparator: \.isNewline).map { String($0) }

        var last: DullPItem? = nil

        for splitedText in splitedTexts {
            if splitedText.starts(with: "practice>") {
                if let arrorIndex = splitedText.firstIndex(of: ">") {
                    let index = splitedText.index(after: arrorIndex)

                    if let _last = last {
                        pItems.append(_last)
                        last = nil
                    }

                    pItems.append(.code(Int(splitedText[index...]) ?? 0))
                }
            } else {
                if last == nil {
                    last = .text("")
                }
                last = last?.update(splitedText + "\n")
            }
        }
    }

    func insertTextBetweenArrayElements(text: String, array: [String]) -> [String] {
        var resultArray = [String]()

        for (index, element) in array.enumerated() {
            resultArray.append(element)

            if index != array.count - 1 {
                resultArray.append(text)
            }
        }

        return resultArray
    }
}

enum DullPItem: Identifiable {
    var id: UUID {
        UUID()
    }

    case text(String)
    case code(Int)

    func type() -> String {
        switch self {
        case .text:
            return "text"
        case .code:
            return "code"
        }
    }

    func update(_ text: String) -> Self {
        switch self {
        case .text(let string):
            return .text(string + text)
        case .code(_):
            return self
        }
    }
}
