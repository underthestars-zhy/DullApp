//
//  DullTextView.swift
//  DullApp
//
//  Created by 朱浩宇 on 2023/4/16.
//

import SwiftUI

struct DullTextView: View {
    let text: String

    @State var ctItems = [DullCTItem]()

    @State var codes = [Holder]()
    
    var body: some View {
        VStack(spacing: 30) {
            ForEach(ctItems) { item in
                switch item {
                case .text(let text):
                    HStack {
                        Text(String(text[text.startIndex..<text.index(before: text.endIndex)]))
                            .font(.system(size: 21, weight: .semibold, design: .monospaced))
                            .lineSpacing(20)
                            .dismissKeyboardOnTap()
                            .foregroundColor(.white)
                            .padding(.horizontal, 50)

                        Spacer()
                    }
                case .code(let index):
                    DocCodeView(holder: codes[index], allCode: allCode(index: index))
                        .padding(.horizontal, 50)
                }
            }
        }
        .padding(.bottom, 30)
        .onAppear {
            generateCTItems()
        }
    }

    func generateCTItems() {
        let splitedTexts = text.split(omittingEmptySubsequences: false, whereSeparator: \.isNewline).map { String($0) }

        var items = [_DullCTItem]()
        var last: _DullCTItem? = nil

        for splitedText in splitedTexts {
            if splitedText.starts(with: "dull>") {
                if let _last = last {
                    if _last.type() != "code" {
                        items.append(_last)
                        last = .code("")
                    }
                } else {
                    last = .code("")
                }

                if let arrorIndex = splitedText.firstIndex(of: ">") {
                    let index = splitedText.index(after: arrorIndex)

                    last = last?.update(String(splitedText[index...]) + "\n")
                }
            } else {
                if let _last = last {
                    if _last.type() != "text" {
                        items.append(_last)
                        last = .text("")
                    }
                } else {
                    last = .text("")
                }

                last = last?.update(splitedText + "\n")
            }
        }

        if let last {
            items.append(last)
        }

        for item in items {
            switch item {
            case .text(let string):
                ctItems.append(.text(string))
            case .code(let string):
                codes.append(Holder(value: String(string[string.startIndex..<string.index(before: string.endIndex)])))
                ctItems.append(.code(codes.count - 1))
            }
        }
    }

    func insertTextBetweenArrayElements(text: String, array: [String]) -> [String] {
        var resultArray = [String]()

        for (index, element) in array.enumerated() {
            resultArray.append(element)

            if index != array.count - 1 {
                resultArray.append(text)
            }
        }

        return resultArray
    }

    func allCode(index: Int) -> [Holder] {
        if index < 1 {
            return []
        } else {
            return codes[0...(index-1)].map { $0 }
        }
    }
}

class Holder {
    var value: String

    init(value: String) {
        self.value = value
    }
}

enum DullCTItem: Identifiable {
    var id: UUID {
        UUID()
    }

    case text(String)
    case code(Int)

    func type() -> String {
        switch self {
        case .text:
            return "text"
        case .code:
            return "code"
        }
    }
}

enum _DullCTItem {
    case text(String)
    case code(String)

    func type() -> String {
        switch self {
        case .text:
            return "text"
        case .code:
            return "code"
        }
    }

    func update(_ text: String) -> Self {
        switch self {
        case .text(let string):
            return .text(string + text)
        case .code(let string):
            return .code(string + text)
        }
    }

    func string(_ text: String) -> String {
        switch self {
        case .text(let string):
            return string
        case .code(let string):
            return string
        }
    }
}


struct DullTextView_Previews: PreviewProvider {
    static var previews: some View {
        DullTextView(text: "")
    }
}

struct DismissKeyboardOnTap: ViewModifier {
    func body(content: Content) -> some View {
        content
            .onTapGesture {
                dismissKeyboard()
            }
    }

    private func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension View {
    func dismissKeyboardOnTap() -> some View {
        self.modifier(DismissKeyboardOnTap())
    }
}
